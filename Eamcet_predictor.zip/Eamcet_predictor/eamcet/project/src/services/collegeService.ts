import axios from 'axios';
import { apiConfig, getAuthHeaders } from '../config/api';

const api = axios.create(apiConfig);

export interface College {
  _id: string;
  SNO: number;
  INSTCODE: string;
  COLLEGE_NAME: string;
  TYPE: string;
  REGION: string;
  DIST: string;
  PLACE: string;
  COED: string;
  AFFL: string;
  ESTD: number;
  branch_code: string;
  OC_BOYS?: number;
  OC_GIRLS?: number;
  SC_BOYS?: number;
  SC_GIRLS?: number;
  ST_BOYS?: number;
  ST_GIRLS?: number;
  BCA_BOYS?: number;
  BCA_GIRLS?: number;
  BCB_BOYS?: number;
  BCB_GIRLS?: number;
  BCC_BOYS?: number;
  BCC_GIRLS?: number;
  BCD_BOYS?: number;
  BCD_GIRLS?: number;
  BCE_BOYS?: number;
  BCE_GIRLS?: number;
  OC_EWS_BOYS?: number;
  OC_EWS_GIRLS?: number;
  COLLEGE_FEE: number;
  year?: number;
  isActive?: boolean;
  lastUpdated?: string;
}

export interface PredictionFilters {
  rank: number;
  gender: 'BOYS' | 'GIRLS';
  category: 'OC' | 'SC' | 'ST' | 'BCA' | 'BCB' | 'BCC' | 'BCD' | 'BCE' | 'OC_EWS';
  branches: string[];
  district?: string;
  collegeType?: string;
  maxFee?: number;
}

export interface CutoffData {
  _id: string;
  college_name: string;
  branch: string;
  gender: string;
  category: string;
  district: string;
  closing_rank: number;
  college_code?: string;
  college_type?: string;
  region?: string;
  place?: string;
  affiliation?: string;
  established_year?: number;
  college_fee?: number;
  year?: number;
  isActive?: boolean;
}

export interface CollegeStats {
  totalColleges: number;
  govtColleges: number;
  privateColleges: number;
  aidedColleges: number;
  totalBranches: number;
  totalDistricts: number;
  branches: string[];
  districts: string[];
  branchDistribution?: { name: string; count: number }[];
  districtDistribution?: { name: string; count: number }[];
}

export interface PaginatedResponse<T> {
  success: boolean;
  data: T[];
  pagination: {
    current: number;
    pages: number;
    total: number;
    limit: number;
  };
}

export const collegeService = {
  async predictColleges(filters: PredictionFilters): Promise<CutoffData[]> {
    try {
      const params = new URLSearchParams({
        rank: filters.rank.toString(),
        gender: filters.gender,
        category: filters.category,
        limit: '50'
      });

      // Only add branches if not empty
      if (filters.branches && filters.branches.length > 0) {
        params.append('branches', filters.branches.join(','));
      }

      if (filters.district) params.append('district', filters.district);
      if (filters.collegeType) params.append('collegeType', filters.collegeType);
      if (filters.maxFee) params.append('maxFee', filters.maxFee.toString());

      const url = `/colleges/predict?${params}`;
      console.log('🔍 Prediction API Request:', url);
      console.log('📊 Filters:', filters);

      const response = await api.get(url);
      
      console.log('✅ Prediction API Response:', response.data);
      
      if (response.data.success) {
        return response.data.colleges || [];
      }
      
      throw new Error(response.data.message || 'Prediction failed');
    } catch (error: any) {
      console.error('❌ Prediction error:', error);
      console.error('Error details:', {
        message: error.message,
        response: error.response?.data,
        status: error.response?.status,
        config: error.config
      });
      throw new Error(error.response?.data?.message || 'Failed to get college predictions');
    }
  },

  async getAllColleges(params?: {
    page?: number;
    limit?: number;
    search?: string;
    branch?: string;
    type?: string;
    district?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }): Promise<{ colleges: College[]; pagination: any }> {
    try {
      const queryParams = new URLSearchParams();
      
      if (params) {
        Object.entries(params).forEach(([key, value]) => {
          if (value !== undefined && value !== '') {
            queryParams.append(key, value.toString());
          }
        });
      }

      const response = await api.get(`/colleges?${queryParams}`);
      
      if (response.data.success) {
        return {
          colleges: response.data.colleges || [],
          pagination: response.data.pagination
        };
      }
      
      throw new Error(response.data.message || 'Failed to fetch colleges');
    } catch (error: any) {
      console.error('Get colleges error:', error);
      throw new Error(error.response?.data?.message || 'Failed to fetch colleges');
    }
  },

  async getCollegeStats(): Promise<CollegeStats> {
    try {
      const response = await api.get('/colleges/stats');
      
      if (response.data.success) {
        return response.data.stats;
      }
      
      throw new Error(response.data.message || 'Failed to fetch statistics');
    } catch (error: any) {
      console.error('Get stats error:', error);
      throw new Error(error.response?.data?.message || 'Failed to fetch statistics');
    }
  },

  async getCollegeById(id: string): Promise<College> {
    try {
      const response = await api.get(`/colleges/${id}`);
      
      if (response.data.success) {
        return response.data.college;
      }
      
      throw new Error(response.data.message || 'College not found');
    } catch (error: any) {
      console.error('Get college error:', error);
      throw new Error(error.response?.data?.message || 'Failed to fetch college details');
    }
  },

  // Admin functions
  async addCollege(college: Omit<College, '_id'>): Promise<College> {
    try {
      const response = await api.post('/colleges', college, {
        headers: getAuthHeaders()
      });
      
      if (response.data.success) {
        return response.data.college;
      }
      
      throw new Error(response.data.message || 'Failed to add college');
    } catch (error: any) {
      console.error('Add college error:', error);
      throw new Error(error.response?.data?.message || 'Failed to add college');
    }
  },

  async updateCollege(id: string, updates: Partial<College>): Promise<College> {
    try {
      const response = await api.put(`/colleges/${id}`, updates, {
        headers: getAuthHeaders()
      });
      
      if (response.data.success) {
        return response.data.college;
      }
      
      throw new Error(response.data.message || 'Failed to update college');
    } catch (error: any) {
      console.error('Update college error:', error);
      throw new Error(error.response?.data?.message || 'Failed to update college');
    }
  },

  async deleteCollege(id: string): Promise<boolean> {
    try {
      const response = await api.delete(`/colleges/${id}`, {
        headers: getAuthHeaders()
      });
      
      return response.data.success;
    } catch (error: any) {
      console.error('Delete college error:', error);
      throw new Error(error.response?.data?.message || 'Failed to delete college');
    }
  },

  async uploadCsv(file: File): Promise<{ success: boolean; message: string; stats?: any }> {
    try {
      const formData = new FormData();
      formData.append('csvFile', file);

      const response = await api.post('/colleges/upload-csv', formData, {
        headers: {
          ...getAuthHeaders(),
          'Content-Type': 'multipart/form-data'
        },
        timeout: 60000 // 60 seconds for file upload
      });

      return {
        success: response.data.success,
        message: response.data.message,
        stats: response.data.stats
      };
    } catch (error: any) {
      console.error('CSV upload error:', error);
      throw new Error(error.response?.data?.message || 'Failed to upload CSV file');
    }
  }
};

// User favorites service
export const favoritesService = {
  async getFavorites(): Promise<College[]> {
    try {
      const response = await api.get('/users/favorites', {
        headers: getAuthHeaders()
      });
      
      if (response.data.success) {
        return response.data.favorites || [];
      }
      
      throw new Error(response.data.message || 'Failed to fetch favorites');
    } catch (error: any) {
      console.error('Get favorites error:', error);
      throw new Error(error.response?.data?.message || 'Failed to fetch favorites');
    }
  },

  async addToFavorites(collegeId: string): Promise<boolean> {
    try {
      const response = await api.post(`/users/favorites/${collegeId}`, {}, {
        headers: getAuthHeaders()
      });
      
      return response.data.success;
    } catch (error: any) {
      console.error('Add favorite error:', error);
      throw new Error(error.response?.data?.message || 'Failed to add to favorites');
    }
  },

  async removeFromFavorites(collegeId: string): Promise<boolean> {
    try {
      console.log('🗑️ Removing from favorites:', collegeId);
      const response = await api.delete(`/users/favorites/${collegeId}`, {
        headers: getAuthHeaders()
      });
      
      console.log('✅ Remove favorite response:', response.data);
      return response.data.success;
    } catch (error: any) {
      console.error('❌ Remove favorite error:', error);
      console.error('Error details:', {
        message: error.message,
        response: error.response?.data,
        status: error.response?.status,
        collegeId: collegeId
      });
      throw new Error(error.response?.data?.message || error.response?.data?.error || 'Failed to remove from favorites');
    }
  }
};