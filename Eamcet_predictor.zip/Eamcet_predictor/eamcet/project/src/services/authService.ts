import axios from 'axios';
import { apiConfig, getAuthHeaders } from '../config/api';

const api = axios.create(apiConfig);

interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'admin';
  favorites?: string[];
  profile?: {
    rank?: number;
    category?: string;
    gender?: string;
    district?: string;
  };
}

interface AuthResult {
  success: boolean;
  user?: User;
  message?: string;
  token?: string;
}

export const authService = {
  async login(email: string, password: string): Promise<AuthResult> {
    try {
      const response = await api.post('/auth/login', { email, password });
      
      if (response.data.success) {
        const { token, user } = response.data;
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));
        return { success: true, user, token };
      }
      
      return { success: false, message: response.data.message || 'Login failed' };
    } catch (error: any) {
      console.error('Login error:', error);
      
      // Handle network errors
      if (!error.response) {
        if (error.code === 'ECONNREFUSED' || error.message.includes('Network Error') || error.message.includes('Failed to fetch')) {
          return { 
            success: false, 
            message: 'Cannot connect to server. Please make sure the backend server is running on http://localhost:5000' 
          };
        }
        if (error.code === 'ETIMEDOUT' || error.message.includes('timeout')) {
          return { 
            success: false, 
            message: 'Connection timeout. Please check your internet connection and try again.' 
          };
        }
        return { 
          success: false, 
          message: 'Network error. Please check your connection and ensure the backend server is running.' 
        };
      }
      
      // Handle validation errors
      if (error.response?.data?.details && Array.isArray(error.response.data.details)) {
        const validationErrors = error.response.data.details
          .map((err: any) => err.msg || err.message)
          .join(', ');
        return { 
          success: false, 
          message: validationErrors || 'Validation failed. Please check your input.' 
        };
      }
      
      return { 
        success: false, 
        message: error.response?.data?.message || error.response?.data?.error || error.message || 'Login failed. Please try again.' 
      };
    }
  },

  async register(name: string, email: string, password: string): Promise<AuthResult> {
    try {
      console.log('Attempting registration with:', { name, email });
      const response = await api.post('/auth/register', { 
        name, 
        email, 
        password,
        role: 'student'
      });
      
      console.log('Registration response:', response.data);
      
      if (response.data.success) {
        const { token, user } = response.data;
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));
        return { success: true, user, token };
      }
      
      return { success: false, message: response.data.message || 'Registration failed' };
    } catch (error: any) {
      console.error('Registration error details:', {
        message: error.message,
        response: error.response?.data,
        status: error.response?.status,
        config: error.config,
        code: error.code
      });
      
      // Handle network errors
      if (!error.response) {
        if (error.code === 'ECONNREFUSED' || error.message.includes('Network Error') || error.message.includes('Failed to fetch')) {
          return { 
            success: false, 
            message: 'Cannot connect to server. Please make sure the backend server is running on http://localhost:5000' 
          };
        }
        if (error.code === 'ETIMEDOUT' || error.message.includes('timeout')) {
          return { 
            success: false, 
            message: 'Connection timeout. Please check your internet connection and try again.' 
          };
        }
        return { 
          success: false, 
          message: 'Network error. Please check your connection and ensure the backend server is running.' 
        };
      }
      
      // Handle validation errors
      if (error.response?.data?.details && Array.isArray(error.response.data.details)) {
        const validationErrors = error.response.data.details
          .map((err: any) => err.msg || err.message)
          .join(', ');
        return { 
          success: false, 
          message: validationErrors || 'Validation failed. Please check your input.' 
        };
      }
      
      return { 
        success: false, 
        message: error.response?.data?.message || error.response?.data?.error || error.message || 'Registration failed. Please try again.' 
      };
    }
  },

  async getCurrentUser(): Promise<User | null> {
    try {
      const token = localStorage.getItem('token');
      if (!token) return null;

      const response = await api.get('/auth/me', {
        headers: getAuthHeaders()
      });

      if (response.data.success) {
        const user = response.data.user;
        localStorage.setItem('user', JSON.stringify(user));
        return user;
      }
      
      return null;
    } catch (error: any) {
      console.error('Get current user error:', error);
      // If token is invalid, clear it
      if (error.response?.status === 401) {
        this.logout();
      }
      return null;
    }
  },

  async updateProfile(profileData: Partial<User>): Promise<AuthResult> {
    try {
      const response = await api.put('/auth/profile', profileData, {
        headers: getAuthHeaders()
      });

      if (response.data.success) {
        const user = response.data.user;
        localStorage.setItem('user', JSON.stringify(user));
        return { success: true, user };
      }

      return { success: false, message: response.data.message || 'Profile update failed' };
    } catch (error: any) {
      console.error('Profile update error:', error);
      return { 
        success: false, 
        message: error.response?.data?.message || 'Profile update failed. Please try again.' 
      };
    }
  },

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  },

  getStoredUser(): User | null {
    const userData = localStorage.getItem('user');
    return userData ? JSON.parse(userData) : null;
  },

  isAuthenticated(): boolean {
    return !!localStorage.getItem('token');
  }
};