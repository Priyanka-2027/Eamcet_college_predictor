import React, { createContext, useContext, useState } from 'react';
import { College, CutoffData } from '../services/collegeService';
import { toast } from '../components/Toaster';

type ComparisonItem = College | CutoffData;

interface ComparisonContextType {
  selectedColleges: ComparisonItem[];
  addToComparison: (college: ComparisonItem) => void;
  removeFromComparison: (collegeId: string) => void;
  clearComparison: () => void;
  isInComparison: (collegeId: string) => boolean;
}

const ComparisonContext = createContext<ComparisonContextType | undefined>(undefined);

export function ComparisonProvider({ children }: { children: React.ReactNode }) {
  const [selectedColleges, setSelectedColleges] = useState<ComparisonItem[]>([]);

  const addToComparison = (college: ComparisonItem) => {
    if (selectedColleges.length >= 5) {
      toast.warning('You can compare up to 5 colleges only');
      return;
    }
    
    const collegeId = college._id;
    if (selectedColleges.some(c => c._id === collegeId)) {
      toast.warning('College already added to comparison');
      return;
    }

    setSelectedColleges(prev => [...prev, college]);
    toast.success('Added to comparison');
  };

  const removeFromComparison = (collegeId: string) => {
    setSelectedColleges(prev => prev.filter(c => c._id !== collegeId));
  };

  const clearComparison = () => {
    setSelectedColleges([]);
  };

  const isInComparison = (collegeId: string) => {
    return selectedColleges.some(c => c._id === collegeId);
  };

  return (
    <ComparisonContext.Provider value={{
      selectedColleges,
      addToComparison,
      removeFromComparison,
      clearComparison,
      isInComparison
    }}>
      {children}
    </ComparisonContext.Provider>
  );
}

export function useComparison() {
  const context = useContext(ComparisonContext);
  if (context === undefined) {
    throw new Error('useComparison must be used within a ComparisonProvider');
  }
  return context;
}
