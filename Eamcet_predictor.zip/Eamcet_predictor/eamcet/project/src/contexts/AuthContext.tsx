
import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { authService } from '../services/authService';

interface User {
  id: string;
  name: string;
  email: string;
  favorites?: string[];
  profile?: {
    rank?: number;
    category?: string;
    gender?: string;
    district?: string;
  };
  lastPrediction?: {
    rank: number;
    category: string;
    gender: string;
    timestamp: Date;
  };
  createdAt?: string;
  updatedAt?: string;
}

interface AuthContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  login: (email: string, password: string) => Promise<{ success: boolean; message?: string }>;
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; message?: string }>;
  logout: () => void;
  loading: boolean;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    initializeAuth();
  }, []);

  const initializeAuth = async () => {
    try {
      const token = localStorage.getItem('token');
      if (token) {
        const userData = await authService.getCurrentUser();
        if (userData) {
          setUser(userData);
        }
      }
    } catch (error) {
      console.error('Auth initialization error:', error);
      // Clear invalid token
      authService.logout();
    } finally {
      setLoading(false);
    }
  };
  const login = async (email: string, password: string): Promise<{ success: boolean; message?: string }> => {
    try {
      const result = await authService.login(email, password);
      if (result.success) {
        setUser(result.user!);
        return { success: true };
      }
      return { success: false, message: result.message };
    } catch (error: any) {
      console.error('Login error:', error);
      return { success: false, message: error?.message || 'Login failed. Please try again.' };
    }
  };

  const register = async (name: string, email: string, password: string): Promise<{ success: boolean; message?: string }> => {
    try {
      console.log('AuthContext: Starting registration process');
      const result = await authService.register(name, email, password);
      console.log('AuthContext: Registration result:', result);
      if (result.success) {
        setUser(result.user!);
        return { success: true };
      }
      console.log('AuthContext: Registration failed:', result.message);
      return { success: false, message: result.message };
    } catch (error: any) {
      console.error('Registration error:', error);
      return { success: false, message: error?.message || 'Registration failed. Please try again.' };
    }
  };

  const refreshUser = async () => {
    try {
      const userData = await authService.getCurrentUser();
      if (userData) {
        setUser(userData);
      }
    } catch (error) {
      console.error('Refresh user error:', error);
    }
  };
  const logout = () => {
    authService.logout();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, login, register, logout, loading, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}