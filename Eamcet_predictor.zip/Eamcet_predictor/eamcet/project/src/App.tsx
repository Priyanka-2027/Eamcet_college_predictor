import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Predictor from './pages/Predictor';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Favorites from './pages/Favorites';
import Updates from './pages/Updates';
import ProtectedRoute from './components/ProtectedRoute';
import { Toaster } from './components/Toaster';

import { ComparisonProvider } from './contexts/ComparisonContext';
import ComparisonBar from './components/ComparisonBar';
import Compare from './pages/Compare';
import Analysis from './pages/Analysis';
import Profile from './pages/Profile';

function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <ComparisonProvider>
          <Router>
            <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 transition-colors duration-200 pb-20">
              <Navbar />
              <main>
                <Routes>
                  <Route path="/" element={<Home />} />
                  <Route path="/predictor" element={<Predictor />} />
                  <Route path="/updates" element={<Updates />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/register" element={<Register />} />
                  <Route path="/compare" element={<Compare />} />
                  <Route path="/dashboard" element={
                    <ProtectedRoute>
                      <Dashboard />
                    </ProtectedRoute>
                  } />
                  <Route path="/favorites" element={
                    <ProtectedRoute>
                      <Favorites />
                    </ProtectedRoute>
                  } />
                  <Route path="/analysis" element={<Analysis />} />
                  <Route path="/profile" element={
                    <ProtectedRoute>
                      <Profile />
                    </ProtectedRoute>
                  } />
                </Routes>
              </main>
              <ComparisonBar />
              <Toaster />
            </div>
          </Router>
        </ComparisonProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}

export default App;