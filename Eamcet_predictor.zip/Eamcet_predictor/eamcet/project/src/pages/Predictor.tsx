import React, { useState, useEffect, useRef } from 'react';
import { Search, BookOpen, Loader2, Heart, ArrowLeft, Download, ChevronDown, Scale } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { collegeService, favoritesService, CutoffData, PredictionFilters } from '../services/collegeService';
import { useAuth } from '../contexts/AuthContext';
import { useComparison } from '../contexts/ComparisonContext';
import { toast } from '../components/Toaster';
import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const branches = [
  { code: 'CSE', name: 'Computer Science & Engineering' },
  { code: 'ECE', name: 'Electronics & Communication Engineering' },
  { code: 'EEE', name: 'Electrical & Electronics Engineering' },
  { code: 'MECH', name: 'Mechanical Engineering' },
  { code: 'CIVIL', name: 'Civil Engineering' },
  { code: 'IT', name: 'Information Technology' },
  { code: 'CHE', name: 'Chemical Engineering' },
  { code: 'AUTO', name: 'Automobile Engineering' },
  { code: 'AERO', name: 'Aeronautical Engineering' },
  { code: 'BIOTECH', name: 'Biotechnology' }
];

const categories = [
  { value: 'OC', label: 'Open Category (OC)' },
  { value: 'SC', label: 'Scheduled Caste (SC)' },
  { value: 'ST', label: 'Scheduled Tribe (ST)' },
  { value: 'BCA', label: 'BC-A' },
  { value: 'BCB', label: 'BC-B' },
  { value: 'BCC', label: 'BC-C' },
  { value: 'BCD', label: 'BC-D' },
  { value: 'BCE', label: 'BC-E' },
  { value: 'OC_EWS', label: 'OC EWS' }
];

const districts = [
  'Anantapur', 'Chittoor', 'East Godavari', 'Guntur', 'Kadapa', 'Krishna',
  'Kurnool', 'Nellore', 'Prakasam', 'Srikakulam', 'Visakhapatnam',
  'Vizianagaram', 'West Godavari'
];

function Predictor() {
  const navigate = useNavigate();
  const resultsRef = useRef<HTMLDivElement>(null);
  const { addToComparison, removeFromComparison, isInComparison, selectedColleges } = useComparison();
  const [filters, setFilters] = useState<PredictionFilters>({
    rank: '' as any,
    gender: 'BOYS',
    category: 'OC',
    branches: [],
    district: ''
  });
  
  const [results, setResults] = useState<CutoffData[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [showBranchDropdown, setShowBranchDropdown] = useState(false);
  const [favoritedColleges, setFavoritedColleges] = useState<Set<string>>(new Set());
  const [autoLoaded, setAutoLoaded] = useState(false);
  const { user } = useAuth();

  // Auto-load last prediction when component mounts
  useEffect(() => {
    const loadLastPrediction = async () => {
      if (user && user.lastPrediction && !autoLoaded) {
        const { rank, category, gender } = user.lastPrediction;
        
        // Set the filters
        setFilters(prev => ({
          ...prev,
          rank,
          category: category as any,
          gender: gender as 'BOYS' | 'GIRLS',
          branches: prev.branches.length > 0 ? prev.branches : branches.map(b => b.code) // Load all branches if none selected
        }));

        // Auto-run the prediction
        try {
          setLoading(true);
          const colleges = await collegeService.predictColleges({
            rank,
            category: category as any,
            gender: gender as 'BOYS' | 'GIRLS',
            branches: branches.map(b => b.code), // Use all branches for auto-load
            district: ''
          });
          setResults(colleges);
          setSearched(true);
          setAutoLoaded(true);
          
          if (colleges.length > 0) {
            toast.success(`Loaded your last search: ${colleges.length} colleges found!`);
            // Scroll to results after a short delay
            setTimeout(() => {
              resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }, 100);
          }
        } catch (error) {
          console.error('Error auto-loading prediction:', error);
        } finally {
          setLoading(false);
        }
      }
    };

    loadLastPrediction();
  }, [user, autoLoaded]);

  useEffect(() => {
    if (user) {
      loadFavorites();
    }
  }, [user]);

  const loadFavorites = async () => {
    try {
      const favorites = await favoritesService.getFavorites();
      // Store _id for CutoffData favorites, or INSTCODE for College favorites
      setFavoritedColleges(new Set(favorites.map(f => f._id || (f as any).INSTCODE)));
    } catch (error) {
      console.error('Error loading favorites:', error);
    }
  };

  const savePrediction = async (rank: number, category: string, gender: string) => {
    if (!user) return;
    
    try {
      const token = localStorage.getItem('token');
      await axios.post(`${API_URL}/auth/save-prediction`, {
        rank,
        category,
        gender
      }, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
    } catch (error) {
      console.error('Error saving prediction:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!filters.rank || filters.branches.length === 0) {
      toast.error('Please enter your rank and select at least one branch');
      return;
    }

    setLoading(true);
    try {
      const rankNum = typeof filters.rank === 'string' ? parseInt(filters.rank) : filters.rank;
      const colleges = await collegeService.predictColleges({
        ...filters,
        rank: rankNum
      });
      setResults(colleges);
      setSearched(true);
      
      // Save prediction for logged-in users
      if (user) {
        await savePrediction(rankNum, filters.category, filters.gender);
      }
      
      if (colleges.length === 0) {
        toast.warning('No colleges found matching your criteria. Try adjusting your preferences.');
      } else {
        toast.success(`Found ${colleges.length} colleges matching your criteria!`);
        // Scroll to results after a short delay
        setTimeout(() => {
          resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 100);
      }
    } catch (error) {
      toast.error('Error fetching results. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const toggleFavorite = async (collegeId: string) => {
    if (!user) {
      toast.warning('Please login to manage favorites');
      return;
    }
    
    try {
      if (favoritedColleges.has(collegeId)) {
        await favoritesService.removeFromFavorites(collegeId);
        setFavoritedColleges(prev => {
          const next = new Set(prev);
          next.delete(collegeId);
          return next;
        });
        toast.success('College removed from favorites');
      } else {
        await favoritesService.addToFavorites(collegeId);
        setFavoritedColleges(prev => new Set(prev).add(collegeId));
        toast.success('College added to favorites!');
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to update favorites');
    }
  };

  const toggleComparison = (college: CutoffData) => {
    if (isInComparison(college._id)) {
      removeFromComparison(college._id);
    } else {
      addToComparison(college);
    }
  };

  const getCutoffRank = (college: CutoffData) => {
    return college.closing_rank;
  };

  const downloadAsCSV = () => {
    if (results.length === 0) {
      toast.warning('No results to download');
      return;
    }

    // Create CSV header
    const headers = ['S.No', 'Rank', 'College Name', 'Branch', 'Type', 'Place', 'District', 'Category', 'Gender', 'Annual Fee', 'Affiliation', 'Established Year'];
    
    // Create CSV rows
    const rows = results.map((college, index) => [
      index + 1,
      college.closing_rank || 'N/A',
      college.college_name || 'N/A',
      college.branch || 'N/A',
      college.college_type || 'N/A',
      college.place || 'N/A',
      college.district || 'N/A',
      college.category || 'N/A',
      college.gender || 'N/A',
      college.college_fee || 'N/A',
      college.affiliation || 'N/A',
      college.established_year || 'N/A'
    ]);

    // Combine headers and rows
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    // Create blob and download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `college_predictions_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success('CSV file downloaded successfully!');
  };

  const downloadAsPDF = () => {
    if (results.length === 0) {
      toast.warning('No results to download');
      return;
    }

    // Create a printable version
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast.error('Please allow popups to download PDF');
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>College Predictions - ${new Date().toLocaleDateString()}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { color: #1e40af; text-align: center; }
            .info { text-align: center; margin-bottom: 20px; color: #666; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 12px; }
            th { background-color: #1e40af; color: white; }
            tr:nth-child(even) { background-color: #f9fafb; }
            .rank { font-weight: bold; color: #2563eb; }
            .govt { color: #059669; font-weight: bold; }
            .pvt { color: #d97706; font-weight: bold; }
            @media print {
              body { margin: 0; }
              @page { margin: 1cm; }
            }
          </style>
        </head>
        <body>
          <h1>AP EAMCET College Predictor - Results</h1>
          <div class="info">
            <p><strong>Your Rank:</strong> ${filters.rank} | <strong>Gender:</strong> ${filters.gender} | <strong>Category:</strong> ${filters.category}</p>
            <p><strong>Generated on:</strong> ${new Date().toLocaleString()}</p>
            <p><strong>Total Colleges Found:</strong> ${results.length}</p>
          </div>
          <table>
            <thead>
              <tr>
                <th>S.No</th>
                <th>Rank</th>
                <th>College Name</th>
                <th>Branch</th>
                <th>Type</th>
                <th>Location</th>
                <th>Category</th>
                <th>Gender</th>
                <th>Fee (₹)</th>
              </tr>
            </thead>
            <tbody>
              ${results.map((college, index) => `
                <tr>
                  <td>${index + 1}</td>
                  <td class="rank">${college.closing_rank?.toLocaleString() || 'N/A'}</td>
                  <td>${college.college_name}<br><small>${college.affiliation || 'N/A'} • Est. ${college.established_year || 'N/A'}</small></td>
                  <td>${college.branch}</td>
                  <td class="${college.college_type === 'GOVT' || college.college_type === 'UNIV' ? 'govt' : 'pvt'}">${college.college_type || 'N/A'}</td>
                  <td>${college.place}, ${college.district}</td>
                  <td>${college.category}</td>
                  <td>${college.gender}</td>
                  <td>${college.college_fee?.toLocaleString() || 'N/A'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
    
    // Wait for content to load, then print
    printWindow.onload = () => {
      printWindow.print();
    };
    
    toast.success('Opening print dialog for PDF download...');
  };

  const toggleBranch = (branchCode: string) => {
    setFilters(prev => ({
      ...prev,
      branches: prev.branches.includes(branchCode)
        ? prev.branches.filter(b => b !== branchCode)
        : [...prev.branches, branchCode]
    }));
  };

  const selectAllBranches = () => {
    const allBranchCodes = branches.map(b => b.code);
    setFilters(prev => ({
      ...prev,
      branches: prev.branches.length === allBranchCodes.length ? [] : allBranchCodes
    }));
  };

  const getSelectedBranchesText = () => {
    if (filters.branches.length === 0) return 'Select branches';
    if (filters.branches.length === branches.length) return 'All Branches Selected';
    if (filters.branches.length === 1) return branches.find(b => b.code === filters.branches[0])?.code || '';
    return `${filters.branches.length} branches selected`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 transition-colors duration-200">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 dark:from-blue-800 dark:to-indigo-900 text-white py-8 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <button
            onClick={() => navigate('/')}
            className="flex items-center space-x-2 text-white/90 hover:text-white mb-4 transition-colors"
          >
            <ArrowLeft size={20} />
            <span>Back to Home</span>
          </button>
          <h1 className="text-4xl font-bold">
            College Predictor
          </h1>
          <p className="text-lg mt-2 text-white/90">
            Enter your details to find eligible colleges
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Prediction Form */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8 transition-colors duration-200">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Enter Your Details
          </h2>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Rank */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  EAMCET Rank *
                </label>
                <input
                  type="number"
                  value={filters.rank}
                  onChange={(e) => setFilters(prev => ({ ...prev, rank: e.target.value as any }))}
                  placeholder="Enter your rank"
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                  required
                  min="1"
                />
              </div>

              {/* Gender */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Gender *
                </label>
                <select
                  value={filters.gender}
                  onChange={(e) => setFilters(prev => ({ ...prev, gender: e.target.value as 'BOYS' | 'GIRLS' }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                >
                  <option value="BOYS">Male</option>
                  <option value="GIRLS">Female</option>
                </select>
              </div>

              {/* Category */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Category *
                </label>
                <select
                  value={filters.category}
                  onChange={(e) => setFilters(prev => ({ ...prev, category: e.target.value as any }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                >
                  {categories.map(cat => (
                    <option key={cat.value} value={cat.value}>{cat.label}</option>
                  ))}
                </select>
              </div>

              {/* District */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Home District (Optional)
                </label>
                <select
                  value={filters.district}
                  onChange={(e) => setFilters(prev => ({ ...prev, district: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                >
                  <option value="">All Districts</option>
                  {districts.map(district => (
                    <option key={district} value={district}>{district}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Branches */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-4">
                Preferred Branches *
              </label>
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowBranchDropdown(!showBranchDropdown)}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-left flex items-center justify-between bg-white transition-colors"
                >
                  <span className={filters.branches.length === 0 ? 'text-gray-500 dark:text-gray-400' : 'text-gray-900 dark:text-white'}>
                    {getSelectedBranchesText()}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 transition-transform ${showBranchDropdown ? 'rotate-180' : ''}`}
                  />
                </button>
                
                {showBranchDropdown && (
                  <div className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg shadow-lg max-h-64 overflow-y-auto">
                    <div className="p-2 border-b border-gray-200 dark:border-gray-700">
                      <button
                        type="button"
                        onClick={selectAllBranches}
                        className="w-full text-left px-3 py-2 text-sm font-medium text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded"
                      >
                        {filters.branches.length === branches.length ? 'Deselect All' : 'Select All Branches'}
                      </button>
                    </div>
                    {branches.map(branch => (
                      <label
                        key={branch.code}
                        className="flex items-center px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer"
                      >
                        <input
                          type="checkbox"
                          checked={filters.branches.includes(branch.code)}
                          onChange={() => toggleBranch(branch.code)}
                          className="mr-3 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700"
                        />
                        <div className="flex-1">
                          <div className="text-sm font-medium text-gray-900 dark:text-white">{branch.code}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{branch.name}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                )}
              </div>
              {filters.branches.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {filters.branches.map(branchCode => (
                    <span
                      key={branchCode}
                      className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200"
                    >
                      {branchCode}
                      <button
                        type="button"
                        onClick={() => toggleBranch(branchCode)}
                        className="ml-1 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-200"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div className="text-center">
              <button
                type="submit"
                disabled={loading}
                className="bg-blue-600 text-white px-8 py-4 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2 mx-auto transition-colors text-lg font-medium"
              >
                {loading ? (
                  <>
                    <Loader2 className="animate-spin" size={20} />
                    <span>Searching...</span>
                  </>
                ) : (
                  <>
                    <Search size={20} />
                    <span>Predict Colleges</span>
                  </>
                )}
              </button>
            </div>
          </form>
          
          {/* Click outside to close dropdown */}
          {showBranchDropdown && (
            <div
              className="fixed inset-0 z-5"
              onClick={() => setShowBranchDropdown(false)}
            />
          )}
        </div>

        {/* Results */}
        {searched && (
          <div ref={resultsRef} className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 transition-colors duration-200">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                  Prediction Results
                </h3>
                {results.length > 0 && (
                  <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    Showing {results.length} colleges (sorted by rank)
                  </div>
                )}
              </div>
              {results.length > 0 && (
                <div className="flex items-center space-x-3">
                  <button
                    onClick={downloadAsCSV}
                    className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium"
                  >
                    <Download size={16} />
                    <span>Download CSV</span>
                  </button>
                  <button
                    onClick={downloadAsPDF}
                    className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                  >
                    <Download size={16} />
                    <span>Download PDF</span>
                  </button>
                </div>
              )}
            </div>

            {results.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-gray-400 dark:text-gray-500 mb-4">
                  <BookOpen size={48} className="mx-auto" />
                </div>
                <h4 className="text-xl font-medium text-gray-900 dark:text-white mb-2">No Results Found</h4>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  No colleges found matching your criteria. Try adjusting your branch preferences or rank.
                </p>
                <button
                  onClick={() => {
                    setFilters(prev => ({ ...prev, branches: [] }));
                    setResults([]);
                    setSearched(false);
                  }}
                  className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Try Different Criteria
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-50 dark:bg-gray-700/50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        S.No
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Rank
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        College Name
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Branch
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Type
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Location
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Category
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Gender
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Annual Fee
                      </th>
                      <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    {results.map((college, index) => (
                      <tr key={college._id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                        <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                          {index + 1}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <div className="text-sm font-bold text-blue-600 dark:text-blue-400">
                            {getCutoffRank(college)?.toLocaleString() || 'N/A'}
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <div className="text-sm font-medium text-gray-900 dark:text-white">
                            {college.college_name}
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            {college.affiliation || 'N/A'} • Est. {college.established_year || 'N/A'}
                          </div>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-200">
                            {college.branch}
                          </span>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            college.college_type === 'GOVT' || college.college_type === 'UNIV' 
                              ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' 
                              : 'bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-200'
                          }`}>
                            {college.college_type || 'N/A'}
                          </span>
                        </td>
                        <td className="px-4 py-4">
                          <div className="text-sm text-gray-900 dark:text-white">{college.place}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{college.district}</div>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200">
                            {college.category}
                          </span>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-pink-100 dark:bg-pink-900 text-pink-800 dark:text-pink-200">
                            {college.gender}
                          </span>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                          ₹{college.college_fee?.toLocaleString() || '0'}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-center">
                          <div className="flex items-center justify-center space-x-2">
                            <button
                              onClick={() => toggleComparison(college)}
                              className={`p-2 rounded-full transition-colors ${
                                isInComparison(college._id)
                                  ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 hover:bg-blue-200 dark:hover:bg-blue-900/50'
                                  : 'hover:bg-blue-50 dark:hover:bg-blue-900/20 text-gray-400 dark:text-gray-500 hover:text-blue-600 dark:hover:text-blue-400'
                              }`}
                              title={isInComparison(college._id) ? 'Remove from comparison' : 'Add to comparison'}
                            >
                              <Scale size={20} />
                            </button>
                            {user && (
                              <button
                                onClick={() => toggleFavorite(college._id)}
                                className={`p-2 rounded-full transition-colors ${
                                  favoritedColleges.has(college._id)
                                    ? 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 hover:bg-red-200 dark:hover:bg-red-900/50'
                                    : 'hover:bg-red-50 dark:hover:bg-red-900/20 text-gray-400 dark:text-gray-500 hover:text-red-600 dark:hover:text-red-400'
                                }`}
                                title={favoritedColleges.has(college._id) ? 'Remove from favorites' : 'Add to favorites'}
                              >
                                <Heart 
                                  size={20} 
                                  fill={favoritedColleges.has(college._id) ? 'currentColor' : 'none'} 
                                />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Floating Comparison Button */}
      {selectedColleges.length > 0 && (
        <div className="fixed bottom-8 right-8 z-50">
          <button
            onClick={() => navigate('/compare')}
            className="bg-blue-600 text-white px-6 py-3 rounded-full shadow-lg hover:bg-blue-700 transition-all flex items-center space-x-2 animate-bounce"
          >
            <Scale size={20} />
            <span className="font-medium">Compare ({selectedColleges.length})</span>
          </button>
        </div>
      )}
    </div>
  );
}
export default Predictor;
