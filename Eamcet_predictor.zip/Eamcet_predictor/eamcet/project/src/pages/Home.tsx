import React from 'react';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, BookOpen, MapPin, Award, Users, Target } from 'lucide-react';

function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            AP EAMCET College Predictor
          </h1>
          <p className="text-xl md:text-2xl mb-10 max-w-3xl mx-auto">
            Find the best engineering colleges based on your EAMCET rank, category, and preferences. 
            Make informed decisions about your future with our comprehensive prediction system.
          </p>
          
          <button
            onClick={() => navigate('/predictor')}
            className="bg-white text-blue-600 px-10 py-4 rounded-lg hover:bg-blue-50 transition-colors text-lg font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
          >
            Start Prediction →
          </button>
          
          <div className="flex justify-center space-x-12 mt-16 text-center">
            <div className="flex flex-col items-center">
              <div className="bg-white/20 rounded-full p-4 mb-3">
                <TrendingUp size={28} />
              </div>
              <span className="text-base font-medium">Accurate Predictions</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="bg-white/20 rounded-full p-4 mb-3">
                <BookOpen size={28} />
              </div>
              <span className="text-base font-medium">All Branches</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="bg-white/20 rounded-full p-4 mb-3">
                <MapPin size={28} />
              </div>
              <span className="text-base font-medium">State-wide Coverage</span>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-4xl font-bold text-center text-gray-900 mb-12">
          Why Choose Our Predictor?
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Feature 1 */}
          <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
            <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mb-4">
              <Target className="text-blue-600" size={32} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">
              Precise Predictions
            </h3>
            <p className="text-gray-600">
              Get accurate college predictions based on previous year cutoff data and your EAMCET rank.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
            <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mb-4">
              <BookOpen className="text-green-600" size={32} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">
              Comprehensive Database
            </h3>
            <p className="text-gray-600">
              Access information about hundreds of engineering colleges across Andhra Pradesh.
            </p>
          </div>

          {/* Feature 3 */}
          <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
            <div className="bg-purple-100 rounded-full w-16 h-16 flex items-center justify-center mb-4">
              <Users className="text-purple-600" size={32} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">
              Category-wise Analysis
            </h3>
            <p className="text-gray-600">
              Filter results by your category (OC, SC, ST, BC) and gender for personalized predictions.
            </p>
          </div>

          {/* Feature 4 */}
          <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
            <div className="bg-orange-100 rounded-full w-16 h-16 flex items-center justify-center mb-4">
              <MapPin className="text-orange-600" size={32} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">
              Location-based Search
            </h3>
            <p className="text-gray-600">
              Find colleges in your preferred districts and regions across the state.
            </p>
          </div>

          {/* Feature 5 */}
          <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
            <div className="bg-red-100 rounded-full w-16 h-16 flex items-center justify-center mb-4">
              <Award className="text-red-600" size={32} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">
              Government & Private
            </h3>
            <p className="text-gray-600">
              Compare both government and private colleges with detailed fee structure information.
            </p>
          </div>

          {/* Feature 6 */}
          <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
            <div className="bg-indigo-100 rounded-full w-16 h-16 flex items-center justify-center mb-4">
              <TrendingUp className="text-indigo-600" size={32} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">
              Updated Data
            </h3>
            <p className="text-gray-600">
              Latest cutoff ranks and college information to help you make the right choice.
            </p>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Find Your Perfect College?
          </h2>
          <p className="text-xl mb-8">
            Enter your EAMCET rank and preferences to get instant predictions
          </p>
          <button
            onClick={() => navigate('/predictor')}
            className="bg-white text-blue-600 px-10 py-4 rounded-lg hover:bg-blue-50 transition-colors text-lg font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
          >
            Get Started Now →
          </button>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-400">
            © 2024 AP EAMCET College Predictor. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
}

export default Home;