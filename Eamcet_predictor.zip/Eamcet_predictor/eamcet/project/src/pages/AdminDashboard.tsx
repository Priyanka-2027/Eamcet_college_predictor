import React, { useState, useEffect } from 'react';
import { collegeService, College } from '../services/collegeService';
import { toast } from '../components/Toaster';
import { 
  Upload, 
  Plus, 
  Edit, 
  Trash2, 
  Search, 
  Filter,
  Download,
  Loader2,
  X,
  Save
} from 'lucide-react';

function AdminDashboard() {
  const [colleges, setColleges] = useState<College[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCollege, setSelectedCollege] = useState<College | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    loadColleges();
  }, []);

  const loadColleges = async () => {
    try {
      setLoading(true);
      const { colleges: data } = await collegeService.getAllColleges({
        limit: 100 // Load more for admin view
      });
      setColleges(data);
    } catch (error) {
      toast.error('Failed to load colleges');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.csv')) {
      toast.error('Please upload a CSV file');
      return;
    }

    setUploading(true);
    try {
      const result = await collegeService.uploadCsv(file);
      toast.success(result.message);
      loadColleges();
    } catch (error) {
      toast.error(error.message || 'Upload failed. Please try again.');
    } finally {
      setUploading(false);
      event.target.value = '';
    }
  };

  const handleAddCollege = async (collegeData: Omit<College, '_id'>) => {
    try {
      await collegeService.addCollege(collegeData);
      toast.success('College added successfully');
      loadColleges();
      setShowAddForm(false);
    } catch (error: any) {
      toast.error(error.message || 'Failed to add college');
    }
  };

  const handleUpdateCollege = async (id: string, updates: Partial<College>) => {
    try {
      await collegeService.updateCollege(id, updates);
      toast.success('College updated successfully');
      loadColleges();
      setIsEditing(false);
      setSelectedCollege(null);
    } catch (error: any) {
      toast.error(error.message || 'Failed to update college');
    }
  };

  const handleDeleteCollege = async (id: string) => {
    if (!confirm('Are you sure you want to delete this college?')) {
      return;
    }

    try {
      await collegeService.deleteCollege(id);
      toast.success('College deleted successfully');
      loadColleges();
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete college');
    }
  };

  const filteredColleges = colleges.filter(college =>
    college.COLLEGE_NAME.toLowerCase().includes(searchTerm.toLowerCase()) ||
    college.INSTCODE.toLowerCase().includes(searchTerm.toLowerCase()) ||
    college.PLACE.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin h-8 w-8 text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
              <p className="text-gray-600 mt-2">Manage college data and cutoff information</p>
            </div>
          </div>

          {/* Action Bar */}
          <div className="bg-gray-50 rounded-xl p-6 mb-8">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <input
                    type="file"
                    accept=".csv"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="csv-upload"
                    disabled={uploading}
                  />
                  <label
                    htmlFor="csv-upload"
                    className={`flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer ${uploading ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    {uploading ? (
                      <>
                        <Loader2 className="animate-spin" size={16} />
                        <span>Uploading...</span>
                      </>
                    ) : (
                      <>
                        <Upload size={16} />
                        <span>Upload CSV</span>
                      </>
                    )}
                  </label>
                </div>

                <button
                  onClick={() => setShowAddForm(true)}
                  className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                >
                  <Plus size={16} />
                  <span>Add College</span>
                </button>

                <button className="flex items-center space-x-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors">
                  <Download size={16} />
                  <span>Export Data</span>
                </button>
              </div>

              <div className="flex items-center space-x-4">
                <div className="relative">
                  <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search colleges..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <button className="flex items-center space-x-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                  <Filter size={16} />
                  <span>Filter</span>
                </button>
              </div>
            </div>
          </div>

          {/* Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl p-6 text-white">
              <h3 className="text-lg font-semibold">Total Colleges</h3>
              <p className="text-3xl font-bold mt-2">{colleges.length}</p>
            </div>
            <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-xl p-6 text-white">
              <h3 className="text-lg font-semibold">Government</h3>
              <p className="text-3xl font-bold mt-2">
                {colleges.filter(c => c.TYPE === 'GOVT').length}
              </p>
            </div>
            <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl p-6 text-white">
              <h3 className="text-lg font-semibold">Private</h3>
              <p className="text-3xl font-bold mt-2">
                {colleges.filter(c => c.TYPE === 'PVT').length}
              </p>
            </div>
            <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl p-6 text-white">
              <h3 className="text-lg font-semibold">Branches</h3>
              <p className="text-3xl font-bold mt-2">
                {new Set(colleges.map(c => c.branch_code)).size}
              </p>
            </div>
          </div>

          {/* Colleges Table */}
          <div className="bg-gray-50 rounded-xl p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">College Data</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-semibold text-gray-900">College</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-900">Code</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-900">Branch</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-900">Type</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-900">Location</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-900">Fee</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredColleges.slice(0, 20).map((college) => (
                    <tr key={college._id} className="border-b border-gray-100 hover:bg-white transition-colors">
                      <td className="py-4 px-4">
                        <div className="font-medium text-gray-900">{college.COLLEGE_NAME}</div>
                      </td>
                      <td className="py-4 px-4 text-gray-600">{college.INSTCODE}</td>
                      <td className="py-4 px-4">
                        <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2 py-1 rounded">
                          {college.branch_code}
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        <span className={`text-xs font-semibold px-2 py-1 rounded ${
                          college.TYPE === 'GOVT' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-orange-100 text-orange-800'
                        }`}>
                          {college.TYPE}
                        </span>
                      </td>
                      <td className="py-4 px-4 text-gray-600">{college.PLACE}, {college.DIST}</td>
                      <td className="py-4 px-4 text-gray-600">₹{college.COLLEGE_FEE?.toLocaleString()}</td>
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => {
                              setSelectedCollege(college);
                              setIsEditing(true);
                            }}
                            className="text-blue-600 hover:text-blue-800 transition-colors"
                            title="Edit"
                          >
                            <Edit size={16} />
                          </button>
                          <button
                            onClick={() => handleDeleteCollege(college._id)}
                            className="text-red-600 hover:text-red-800 transition-colors"
                            title="Delete"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {filteredColleges.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                No colleges found matching your search criteria.
              </div>
            )}
            
            {filteredColleges.length > 20 && (
              <div className="text-center py-4 text-gray-600">
                Showing 20 of {filteredColleges.length} results. Use search to narrow down.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Edit Modal */}
      {isEditing && selectedCollege && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-screen overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-bold text-gray-900">Edit College</h3>
                <button
                  onClick={() => {
                    setIsEditing(false);
                    setSelectedCollege(null);
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X size={24} />
                </button>
              </div>
            </div>
            <div className="p-6">
              <p className="text-gray-600 mb-4">Editing: {selectedCollege.COLLEGE_NAME}</p>
              <div className="text-center py-8 text-gray-500">
                College edit form would be implemented here with all the necessary fields for updating college information.
              </div>
              <div className="flex justify-end space-x-4 mt-6">
                <button
                  onClick={() => {
                    setIsEditing(false);
                    setSelectedCollege(null);
                  }}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                  <Save size={16} />
                  <span>Save Changes</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add College Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-screen overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-bold text-gray-900">Add New College</h3>
                <button
                  onClick={() => setShowAddForm(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X size={24} />
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="text-center py-8 text-gray-500">
                Add college form would be implemented here with all the necessary fields for creating a new college entry.
              </div>
              <div className="flex justify-end space-x-4 mt-6">
                <button
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                  <Plus size={16} />
                  <span>Add College</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminDashboard;