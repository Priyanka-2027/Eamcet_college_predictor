import React, { useState } from 'react';
import { Calendar, Bell, ExternalLink, Download, Clock, AlertCircle } from 'lucide-react';

interface Update {
  id: number;
  title: string;
  date: string;
  category: 'important' | 'schedule' | 'result' | 'notification';
  description: string;
  link?: string;
  isNew?: boolean;
}

function Updates() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const updates: Update[] = [
    {
      id: 1,
      title: 'AP EAMCET 2024 Final Phase Counseling Schedule Released',
      date: '2024-11-20',
      category: 'important',
      description: 'The final phase counseling for AP EAMCET 2024 will commence from November 25th. Students are advised to complete their web options before the deadline.',
      link: 'https://apeamcet.nic.in',
      isNew: true
    },
    {
      id: 2,
      title: 'Document Verification for Phase 2 Counseling',
      date: '2024-11-18',
      category: 'schedule',
      description: 'Document verification for Phase 2 counseling will be conducted from November 22nd to November 24th at designated help centers across AP.',
      link: 'https://apeamcet.nic.in'
    },
    {
      id: 3,
      title: 'Seat Allotment Results - Phase 1',
      date: '2024-11-15',
      category: 'result',
      description: 'Phase 1 seat allotment results have been declared. Candidates can check their allotment status on the official website.',
      link: 'https://apeamcet.nic.in'
    },
    {
      id: 4,
      title: 'Important Notice: Fee Payment Deadline Extended',
      date: '2024-11-12',
      category: 'notification',
      description: 'The deadline for fee payment has been extended to November 20th due to technical issues. Students are requested to complete the payment at the earliest.',
      isNew: true
    },
    {
      id: 5,
      title: 'Web Options Entry for Engineering Courses',
      date: '2024-11-10',
      category: 'schedule',
      description: 'Web options entry for engineering courses is now open. Students can fill their preferences until November 18th, 5:00 PM.',
      link: 'https://apeamcet.nic.in'
    },
    {
      id: 6,
      title: 'Spot Admission Schedule Announced',
      date: '2024-11-08',
      category: 'important',
      description: 'Spot admission for vacant seats will be conducted from December 1st to December 5th. Eligible candidates must report to their allotted colleges with original documents.'
    },
    {
      id: 7,
      title: 'Certificate Verification Guidelines',
      date: '2024-11-05',
      category: 'notification',
      description: 'Detailed guidelines for certificate verification have been released. Please ensure all documents are in order before attending verification.'
    },
    {
      id: 8,
      title: 'Scholarship Application Deadline',
      date: '2024-11-01',
      category: 'important',
      description: 'Students seeking scholarships must submit their applications by November 30th. Late applications will not be entertained.',
      link: 'https://scholarships.ap.gov.in'
    }
  ];

  const categories = [
    { value: 'all', label: 'All Updates', color: 'blue' },
    { value: 'important', label: 'Important', color: 'red' },
    { value: 'schedule', label: 'Schedule', color: 'green' },
    { value: 'result', label: 'Results', color: 'purple' },
    { value: 'notification', label: 'Notifications', color: 'orange' }
  ];

  const filteredUpdates = selectedCategory === 'all' 
    ? updates 
    : updates.filter(update => update.category === selectedCategory);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'important': return 'bg-red-100 text-red-800 border-red-200';
      case 'schedule': return 'bg-green-100 text-green-800 border-green-200';
      case 'result': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'notification': return 'bg-orange-100 text-orange-800 border-orange-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'important': return <AlertCircle size={16} />;
      case 'schedule': return <Calendar size={16} />;
      case 'result': return <Download size={16} />;
      case 'notification': return <Bell size={16} />;
      default: return <Bell size={16} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-blue-100 p-3 rounded-xl">
              <Bell size={32} className="text-blue-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Counseling Updates</h1>
              <p className="text-gray-600 mt-1">Stay updated with the latest AP EAMCET counseling news</p>
            </div>
          </div>

          {/* Category Filters */}
          <div className="flex flex-wrap gap-2 mt-6">
            {categories.map((category) => (
              <button
                key={category.value}
                onClick={() => setSelectedCategory(category.value)}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  selectedCategory === category.value
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>

        {/* Updates List */}
        <div className="space-y-4">
          {filteredUpdates.length === 0 ? (
            <div className="bg-white rounded-xl p-12 text-center">
              <Bell size={48} className="mx-auto text-gray-400 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">No Updates Found</h3>
              <p className="text-gray-600">There are no updates in this category.</p>
            </div>
          ) : (
            filteredUpdates.map((update) => (
              <div
                key={update.id}
                className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow p-6 border-l-4 border-blue-500"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-bold border ${getCategoryColor(update.category)}`}>
                        {getCategoryIcon(update.category)}
                        <span className="capitalize">{update.category}</span>
                      </span>
                      {update.isNew && (
                        <span className="bg-red-500 text-white px-2 py-1 rounded-full text-xs font-bold animate-pulse">
                          NEW
                        </span>
                      )}
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">
                      {update.title}
                    </h3>
                    <div className="flex items-center space-x-2 text-sm text-gray-600 mb-3">
                      <Clock size={14} />
                      <span>{new Date(update.date).toLocaleDateString('en-IN', { 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })}</span>
                    </div>
                  </div>
                </div>

                <p className="text-gray-700 mb-4 leading-relaxed">
                  {update.description}
                </p>

                {update.link && (
                  <a
                    href={update.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium transition-colors"
                  >
                    <span>Read More</span>
                    <ExternalLink size={16} />
                  </a>
                )}
              </div>
            ))
          )}
        </div>

        {/* Important Notice */}
        <div className="bg-yellow-50 border-2 border-yellow-200 rounded-xl p-6 mt-6">
          <div className="flex items-start space-x-3">
            <AlertCircle size={24} className="text-yellow-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-lg font-bold text-yellow-900 mb-2">Important Notice</h3>
              <p className="text-yellow-800">
                Please regularly check the official AP EAMCET website for the most up-to-date information. 
                This page is for informational purposes only. Always verify important dates and announcements 
                from official sources.
              </p>
              <a
                href="https://apeamcet.nic.in"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-2 mt-3 text-yellow-900 font-bold hover:text-yellow-700 transition-colors"
              >
                <span>Visit Official Website</span>
                <ExternalLink size={16} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Updates;
