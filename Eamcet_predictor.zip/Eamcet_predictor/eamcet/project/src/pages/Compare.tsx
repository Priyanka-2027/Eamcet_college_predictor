import { useNavigate } from 'react-router-dom';
import { ArrowLeft, X } from 'lucide-react';
import { useComparison } from '../contexts/ComparisonContext';
import { CutoffData, College } from '../services/collegeService';

export default function Compare() {
  const { selectedColleges, removeFromComparison, clearComparison } = useComparison();
  const navigate = useNavigate();

  if (selectedColleges.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4 transition-colors duration-200">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">No colleges selected</h2>
          <button
            onClick={() => navigate('/predictor')}
            className="text-blue-600 dark:text-blue-400 hover:underline"
          >
            Go back to Predictor
          </button>
        </div>
      </div>
    );
  }

  const isCutoff = (item: College | CutoffData): item is CutoffData => {
    return 'closing_rank' in item;
  };

  const getValue = (college: College | CutoffData, field: string) => {
    if (isCutoff(college)) {
      switch (field) {
        case 'name': return college.college_name;
        case 'code': return college.college_code;
        case 'type': return college.college_type;
        case 'fee': return `₹${college.college_fee?.toLocaleString()}`;
        case 'estd': return college.established_year;
        case 'place': return `${college.place}, ${college.district}`;
        case 'affl': return college.affiliation;
        case 'coed': return college.gender;
        case 'rank': return college.closing_rank?.toLocaleString();
        default: return '-';
      }
    } else {
      switch (field) {
        case 'name': return college.COLLEGE_NAME;
        case 'code': return college.INSTCODE;
        case 'type': return college.TYPE;
        case 'fee': return `₹${college.COLLEGE_FEE?.toLocaleString()}`;
        case 'estd': return college.ESTD;
        case 'place': return `${college.PLACE}, ${college.DIST}`;
        case 'affl': return college.AFFL;
        case 'coed': return college.COED;
        case 'rank': return '-';
        default: return '-';
      }
    }
  };

  const features = [
    { label: 'College Name', key: 'name' },
    { label: 'Code', key: 'code' },
    { label: 'Type', key: 'type' },
    { label: 'Annual Fee', key: 'fee' },
    { label: 'Established', key: 'estd' },
    { label: 'Location', key: 'place' },
    { label: 'Affiliation', key: 'affl' },
    { label: 'Co-Ed/Gender', key: 'coed' },
    { label: 'Closing Rank', key: 'rank' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 py-8 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back</span>
        </button>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden transition-colors duration-200">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">College Comparison</h1>
              <p className="text-gray-600 dark:text-gray-400 mt-1">
                Comparing {selectedColleges.length} colleges side by side
              </p>
            </div>
            <button
              onClick={clearComparison}
              className="px-4 py-2 text-sm font-medium text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 hover:bg-red-100 dark:hover:bg-red-900/40 rounded-lg transition-colors"
            >
              Clear All
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-900/50 w-48">
                    Features
                  </th>
                  {selectedColleges.map((college) => (
                    <th key={college._id} className="px-6 py-4 text-left bg-white dark:bg-gray-800 min-w-[250px] relative group">
                      <div className="flex justify-between items-start">
                        <span className="text-lg font-bold text-gray-900 dark:text-white block mb-2">
                          {getValue(college, 'name')}
                        </span>
                        <button
                          onClick={() => removeFromComparison(college._id)}
                          className="text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X size={20} />
                        </button>
                      </div>
                      <span className={`inline-block px-2 py-1 text-xs font-semibold rounded-full ${
                        getValue(college, 'type') === 'GOVT' || getValue(college, 'type') === 'UNIV'
                          ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200'
                          : 'bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-200'
                      }`}>
                        {getValue(college, 'type')}
                      </span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                {features.slice(1).map((feature) => (
                  <tr key={feature.key} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-900/50">
                      {feature.label}
                    </td>
                    {selectedColleges.map((college) => (
                      <td key={college._id} className="px-6 py-4 text-sm text-gray-900 dark:text-white font-medium">
                        {getValue(college, feature.key)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
