import { useState, useEffect } from 'react';
import { Heart, MapPin, Users, Trash2, Search, Download } from 'lucide-react';
import { favoritesService, College, CutoffData } from '../services/collegeService';
import { useComparison } from '../contexts/ComparisonContext';
import { toast } from '../components/Toaster';

type FavoriteItem = College | CutoffData;

// Type guard to check if item is CutoffData
const isCutoffData = (item: FavoriteItem): item is CutoffData => {
  return 'college_name' in item && 'closing_rank' in item;
};

function Favorites() {
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const { addToComparison, removeFromComparison, isInComparison, selectedColleges } = useComparison();

  useEffect(() => {
    loadFavorites();
  }, []);

  const loadFavorites = async () => {
    try {
      setLoading(true);
      const data = await favoritesService.getFavorites();
      setFavorites(data);
    } catch (error: any) {
      toast.error(error.message || 'Failed to load favorites');
    } finally {
      setLoading(false);
    }
  };
  
  const removeFavorite = async (collegeId: string) => {
    try {
      await favoritesService.removeFromFavorites(collegeId);
      setFavorites(prev => prev.filter(college => college._id !== collegeId));
      toast.success('College removed from favorites');
    } catch (error: any) {
      toast.error(error.message || 'Failed to remove from favorites');
    }
  };

  const getCollegeName = (item: FavoriteItem): string => {
    return isCutoffData(item) ? item.college_name : item.COLLEGE_NAME;
  };

  const getBranch = (item: FavoriteItem): string => {
    return isCutoffData(item) ? item.branch : item.branch_code;
  };

  const filteredFavorites = favorites.filter(college => {
    const name = getCollegeName(college).toLowerCase();
    const branch = getBranch(college).toLowerCase();
    const search = searchTerm.toLowerCase();
    return name.includes(search) || branch.includes(search);
  });

  const downloadAsCSV = () => {
    if (favorites.length === 0) {
      toast.warning('No favorites to download');
      return;
    }

    // Create CSV header
    const headers = ['S.No', 'College Name', 'Branch', 'Type', 'Place', 'District', 'Category', 'Gender', 'Annual Fee', 'Affiliation', 'Established Year'];
    
    // Create CSV rows
    const rows = filteredFavorites.map((college, index) => {
      const isCutoff = isCutoffData(college);
      return [
        index + 1,
        getCollegeName(college),
        getBranch(college),
        isCutoff ? college.college_type : college.TYPE,
        isCutoff ? college.place : college.PLACE,
        isCutoff ? college.district : college.DIST,
        isCutoff ? college.category : 'N/A',
        isCutoff ? college.gender : college.COED,
        (isCutoff ? college.college_fee : college.COLLEGE_FEE) || 0,
        isCutoff ? college.affiliation : college.AFFL,
        isCutoff ? college.established_year : college.ESTD
      ].map(cell => `"${cell}"`).join(',');
    }).join('\n');

    const csvContent = `${headers.join(',')}\n${rows}`;

    // Create blob and download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `favorite_colleges_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success('Favorites exported to CSV!');
  };

  const downloadAsPDF = () => {
    if (favorites.length === 0) {
      toast.warning('No favorites to download');
      return;
    }

    // Create a printable version
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast.error('Please allow popups to download PDF');
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>My Favorite Colleges - ${new Date().toLocaleDateString()}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { color: #1e40af; text-align: center; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
            th { background-color: #f3f4f6; color: #374151; }
            tr:nth-child(even) { background-color: #f9fafb; }
            .badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
            .govt { background-color: #d1fae5; color: #065f46; }
            .pvt { background-color: #ffedd5; color: #9a3412; }
          </style>
        </head>
        <body>
          <h1>My Favorite Colleges</h1>
          <table>
            <thead>
              <tr>
                <th>S.No</th>
                <th>College Name</th>
                <th>Branch</th>
                <th>Type</th>
                <th>Location</th>
                <th>Fee</th>
              </tr>
            </thead>
            <tbody>
              ${filteredFavorites.map((college, index) => {
                const isCutoff = isCutoffData(college);
                const type = isCutoff ? college.college_type : college.TYPE;
                const typeClass = (type === 'GOVT' || type === 'UNIV') ? 'govt' : 'pvt';
                
                return `
                  <tr>
                    <td>${index + 1}</td>
                    <td>
                      <strong>${getCollegeName(college)}</strong><br/>
                      <small>${isCutoff ? college.affiliation : college.AFFL}</small>
                    </td>
                    <td>${getBranch(college)}</td>
                    <td><span class="badge ${typeClass}">${type}</span></td>
                    <td>${isCutoff ? college.place : college.PLACE}, ${isCutoff ? college.district : college.DIST}</td>
                    <td>₹${((isCutoff ? college.college_fee : college.COLLEGE_FEE) || 0).toLocaleString()}</td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
    
    // Wait for content to load, then print
    printWindow.onload = () => {
      printWindow.print();
    };
    
    toast.success('Opening print dialog for PDF download...');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center transition-colors duration-200">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 dark:border-blue-400"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 py-8 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 transition-colors duration-200">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-3">
              <Heart size={32} className="text-red-500" fill="currentColor" />
              <div>
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white">My Favorites</h1>
                <p className="text-gray-600 dark:text-gray-400 mt-1">Manage your saved colleges</p>
              </div>
            </div>
            
            {favorites.length > 0 && (
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search favorites..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                  />
                </div>
                <button
                  onClick={downloadAsCSV}
                  className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium"
                >
                  <Download size={16} />
                  <span>CSV</span>
                </button>
                <button
                  onClick={downloadAsPDF}
                  className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                >
                  <Download size={16} />
                  <span>PDF</span>
                </button>
              </div>
            )}
          </div>

          {favorites.length === 0 ? (
            <div className="text-center py-16">
              <div className="text-gray-400 dark:text-gray-500 mb-6">
                <Heart size={64} className="mx-auto" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">No Favorites Yet</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
                Start exploring colleges and add them to your favorites to keep track of your preferred options.
              </p>
              <a
                href="/predictor"
                className="inline-flex items-center bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium"
              >
                Predict Colleges
              </a>
            </div>
          ) : (
            <>
              <div className="mb-6 text-gray-600 dark:text-gray-400">
                Showing {filteredFavorites.length} of {favorites.length} favorites
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredFavorites.map((college) => {
                  const isCutoff = isCutoffData(college);
                  
                  return (
                    <div key={college._id} className="border border-gray-200 dark:border-gray-700 rounded-xl p-6 hover:shadow-md transition-all dark:bg-gray-800/50">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className={`text-xs font-bold px-2 py-1 rounded ${
                              (isCutoff ? college.college_type : college.TYPE) === 'GOVT' || 
                              (isCutoff ? college.college_type : college.TYPE) === 'UNIV'
                                ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' 
                                : 'bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-200'
                            }`}>
                              {isCutoff ? college.college_type : college.TYPE}
                            </span>
                            <span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs font-bold px-2 py-1 rounded">
                              {isCutoff ? college.branch : college.branch_code}
                            </span>
                            {isCutoff && (
                              <>
                                <span className="bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200 text-xs font-bold px-2 py-1 rounded">
                                  {college.category}
                                </span>
                                <span className="bg-pink-100 dark:bg-pink-900 text-pink-800 dark:text-pink-200 text-xs font-bold px-2 py-1 rounded">
                                  {college.gender}
                                </span>
                              </>
                            )}
                          </div>
                          <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                            {getCollegeName(college)}
                          </h4>
                          <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400 mb-4">
                            <span className="flex items-center space-x-1">
                              <MapPin size={14} />
                              <span>
                                {isCutoff ? `${college.place}, ${college.district}` : `${college.PLACE}, ${college.DIST}`}
                              </span>
                            </span>
                            {!isCutoff && (
                              <span className="flex items-center space-x-1">
                                <Users size={14} />
                                <span>{college.COED}</span>
                              </span>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <div className="flex items-center space-x-2 mr-2">
                            <input
                              type="checkbox"
                              checked={isInComparison(college._id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  addToComparison(college);
                                } else {
                                  removeFromComparison(college._id);
                                }
                              }}
                              disabled={!isInComparison(college._id) && selectedColleges.length >= 5}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                            />
                            <span className="text-sm text-gray-500 dark:text-gray-400">Compare</span>
                          </div>
                          <button
                            onClick={() => removeFavorite(college._id)}
                            className="text-red-500 hover:text-red-700 dark:hover:text-red-400 transition-colors p-1"
                            title="Remove from favorites"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                        {isCutoff && (
                          <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3">
                            <div className="text-gray-600 dark:text-gray-400 mb-1">Closing Rank</div>
                            <div className="text-lg font-bold text-blue-600 dark:text-blue-400">
                              {college.closing_rank?.toLocaleString() || 'N/A'}
                            </div>
                          </div>
                        )}
                        <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3">
                          <div className="text-gray-600 dark:text-gray-400 mb-1">Annual Fee</div>
                          <div className="text-lg font-bold text-green-600 dark:text-green-400">
                            ₹{(isCutoff ? college.college_fee : college.COLLEGE_FEE)?.toLocaleString() || 'N/A'}
                          </div>
                        </div>
                        <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3">
                          <div className="text-gray-600 dark:text-gray-400 mb-1">Established</div>
                          <div className="text-lg font-bold text-blue-600 dark:text-blue-400">
                            {isCutoff ? college.established_year : college.ESTD}
                          </div>
                        </div>
                      </div>

                      <div className="pt-4 border-t border-gray-100 dark:border-gray-700 text-sm text-gray-600 dark:text-gray-400">
                        <div className="flex justify-between">
                          <span>Affiliated: {isCutoff ? college.affiliation : college.AFFL}</span>
                          {!isCutoff && <span>Code: {college.INSTCODE}</span>}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default Favorites;