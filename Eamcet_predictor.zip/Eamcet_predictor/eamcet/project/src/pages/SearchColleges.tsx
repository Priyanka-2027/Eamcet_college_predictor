import React, { useState } from 'react';
import { Search, MapPin, Building2, Wallet, Loader2, Scale } from 'lucide-react';
import { collegeService, College } from '../services/collegeService';
import { useComparison } from '../contexts/ComparisonContext';
import { toast } from '../components/Toaster';

export default function SearchColleges() {
  const { addToComparison, removeFromComparison, isInComparison } = useComparison();
  const [searchTerm, setSearchTerm] = useState('');
  // ... rest of the component state

  const [colleges, setColleges] = useState<College[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [filters, setFilters] = useState({
    type: '',
    district: ''
  });

  const toggleComparison = (college: College) => {
    if (isInComparison(college._id)) {
      removeFromComparison(college._id);
    } else {
      addToComparison(college);
    }
  };

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    if (!searchTerm.trim()) {
      toast.warning('Please enter a college name or code');
      return;
    }

    setLoading(true);
    try {
      const { colleges: data } = await collegeService.getAllColleges({
        search: searchTerm,
        type: filters.type,
        district: filters.district,
        limit: 50
      });
      setColleges(data);
      setSearched(true);
    } catch (error) {
      toast.error('Failed to search colleges');
    } finally {
      setLoading(false);
    }
  };

  const districts = [
    'Anantapur', 'Chittoor', 'East Godavari', 'Guntur', 'Kadapa', 'Krishna',
    'Kurnool', 'Nellore', 'Prakasam', 'Srikakulam', 'Visakhapatnam',
    'Vizianagaram', 'West Godavari'
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
            Search Colleges
          </h1>
          
          <form onSubmit={handleSearch} className="max-w-3xl">
            <div className="flex gap-4 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by college name, code, or branch..."
                  className="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="px-8 py-3 bg-blue-600 text-white font-medium rounded-xl hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center gap-2"
              >
                {loading ? <Loader2 className="animate-spin" size={20} /> : <Search size={20} />}
                Search
              </button>
            </div>

            <div className="flex flex-wrap gap-4">
              <select
                value={filters.type}
                onChange={(e) => setFilters(prev => ({ ...prev, type: e.target.value }))}
                className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="">All Types</option>
                <option value="GOVT">Government</option>
                <option value="PVT">Private</option>
                <option value="UNIV">University</option>
              </select>

              <select
                value={filters.district}
                onChange={(e) => setFilters(prev => ({ ...prev, district: e.target.value }))}
                className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="">All Districts</option>
                {districts.map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>
          </form>
        </div>
      </div>

      {/* Results */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {searched && (
          <div className="mb-6 text-gray-600 dark:text-gray-400">
            Found {colleges.length} results
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {colleges.map((college) => (
            <div 
              key={college._id}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-shadow p-6 border border-gray-100 dark:border-gray-700"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h3 className="font-bold text-gray-900 dark:text-white text-lg line-clamp-2">
                    {college.COLLEGE_NAME}
                  </h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-sm font-medium text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20 px-2 py-0.5 rounded">
                      {college.INSTCODE}
                    </span>
                    <span className="text-sm font-medium text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-900/20 px-2 py-0.5 rounded">
                      {college.branch_code}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <button
                    onClick={() => toggleComparison(college)}
                    className={`p-2 rounded-lg transition-colors ${
                      isInComparison(college._id)
                        ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/40 dark:text-blue-400'
                        : 'bg-gray-100 text-gray-400 hover:text-blue-600 dark:bg-gray-700 dark:text-gray-500 dark:hover:text-blue-400'
                    }`}
                    title={isInComparison(college._id) ? "Remove from comparison" : "Add to comparison"}
                  >
                    <Scale size={20} />
                  </button>
                  <span className={`text-xs font-bold px-2 py-1 rounded ${
                    college.TYPE === 'GOVT' || college.TYPE === 'UNIV'
                      ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                      : 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400'
                  }`}>
                    {college.TYPE}
                  </span>
                </div>
              </div>

              <div className="space-y-3 text-sm text-gray-600 dark:text-gray-300 mb-6">
                <div className="flex items-center gap-2">
                  <MapPin size={16} className="text-gray-400" />
                  <span>{college.PLACE}, {college.DIST}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Building2 size={16} className="text-gray-400" />
                  <span>Est. {college.ESTD} • {college.AFFL}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Wallet size={16} className="text-gray-400" />
                  <span>₹{college.COLLEGE_FEE?.toLocaleString()} / year</span>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-100 dark:border-gray-700">
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-gray-500 dark:text-gray-400 block">OC Boys</span>
                    <span className="font-bold text-gray-900 dark:text-white">
                      {college.OC_BOYS?.toLocaleString() || 'N/A'}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500 dark:text-gray-400 block">OC Girls</span>
                    <span className="font-bold text-gray-900 dark:text-white">
                      {college.OC_GIRLS?.toLocaleString() || 'N/A'}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500 dark:text-gray-400 block">SC Boys</span>
                    <span className="font-bold text-gray-900 dark:text-white">
                      {college.SC_BOYS?.toLocaleString() || 'N/A'}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500 dark:text-gray-400 block">ST Boys</span>
                    <span className="font-bold text-gray-900 dark:text-white">
                      {college.ST_BOYS?.toLocaleString() || 'N/A'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {searched && colleges.length === 0 && (
          <div className="text-center py-12">
            <Search size={48} className="mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-medium text-gray-900 dark:text-white mb-2">No colleges found</h3>
            <p className="text-gray-500 dark:text-gray-400">
              Try adjusting your search terms or filters
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
