import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { GraduationCap, User, Calendar, Heart } from 'lucide-react';

function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 py-12 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 transition-colors duration-200">
          <div className="text-center mb-12">
            <div className="bg-blue-100 dark:bg-blue-900/50 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-6">
              <User size={48} className="text-blue-600 dark:text-blue-400" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
              Welcome, {user?.name}!
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-400">
              Student Dashboard
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Predict Colleges */}
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Predict Colleges</h3>
                  <p className="text-blue-100 text-sm">
                    Find colleges based on your rank and preferences
                  </p>
                </div>
                <GraduationCap size={32} className="text-blue-200" />
              </div>
              <button 
                onClick={() => navigate('/predictor')}
                className="mt-4 bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg transition-colors text-sm font-medium"
              >
                Start Prediction
              </button>
            </div>

            {/* My Favorites */}
            <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-xl p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold mb-2">My Favorites</h3>
                  <p className="text-red-100 text-sm">
                    View and manage your saved colleges
                  </p>
                </div>
                <Heart size={32} className="text-red-200" />
              </div>
              <button 
                onClick={() => navigate('/favorites')}
                className="mt-4 bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg transition-colors text-sm font-medium"
              >
                View Favorites
              </button>
            </div>

            {/* Counseling Updates */}
            <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Counseling Updates</h3>
                  <p className="text-green-100 text-sm">
                    Stay updated with latest counseling news
                  </p>
                </div>
                <Calendar size={32} className="text-green-200" />
              </div>
              <button 
                onClick={() => navigate('/updates')}
                className="mt-4 bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg transition-colors text-sm font-medium"
              >
                View Updates
              </button>
            </div>

            {/* Data Analysis */}
            <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Data Analysis</h3>
                  <p className="text-purple-100 text-sm">
                    Explore college trends and statistics
                  </p>
                </div>
                <div className="bg-white/20 p-2 rounded-lg">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
                </div>
              </div>
              <button 
                onClick={() => navigate('/analysis')}
                className="mt-4 bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg transition-colors text-sm font-medium"
              >
                View Insights
              </button>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;