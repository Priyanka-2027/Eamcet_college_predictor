import { useNavigate } from 'react-router-dom';
import { X, ArrowRight } from 'lucide-react';
import { useComparison } from '../contexts/ComparisonContext';
import { CutoffData, College } from '../services/collegeService';

export default function ComparisonBar() {
  const { selectedColleges, removeFromComparison, clearComparison } = useComparison();
  const navigate = useNavigate();

  if (selectedColleges.length === 0) return null;

  const getCollegeName = (item: College | CutoffData) => {
    return 'college_name' in item ? item.college_name : item.COLLEGE_NAME;
  };

  const getId = (item: College | CutoffData) => {
    return item._id;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-lg transform transition-transform duration-300 z-50">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-8 py-3 sm:py-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-0">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-6 w-full sm:w-auto">
            <div className="flex items-center gap-2 sm:gap-3">
              <span className="text-xs sm:text-sm font-medium text-gray-500 dark:text-gray-400 whitespace-nowrap">
                Comparing {selectedColleges.length}/5
              </span>
              <button
                onClick={clearComparison}
                className="text-xs text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 underline"
              >
                Clear all
              </button>
            </div>

            <div className="flex gap-2 overflow-x-auto max-w-full sm:max-w-none pb-2 sm:pb-0 scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-gray-600">
              {selectedColleges.map((college) => (
                <div
                  key={getId(college)}
                  className="flex items-center gap-1.5 sm:gap-2 bg-gray-100 dark:bg-gray-700 px-2 sm:px-3 py-1 sm:py-1.5 rounded-full whitespace-nowrap flex-shrink-0"
                >
                  <span className="text-xs sm:text-sm font-medium text-gray-900 dark:text-white truncate max-w-[100px] sm:max-w-[150px]">
                    {getCollegeName(college)}
                  </span>
                  <button
                    onClick={() => removeFromComparison(getId(college))}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 flex-shrink-0"
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => navigate('/compare')}
            disabled={selectedColleges.length < 2}
            className="w-full sm:w-auto flex items-center justify-center gap-2 bg-blue-600 text-white px-4 sm:px-6 py-2 sm:py-2.5 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium shadow-sm text-sm sm:text-base"
          >
            <span>Compare Now</span>
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
