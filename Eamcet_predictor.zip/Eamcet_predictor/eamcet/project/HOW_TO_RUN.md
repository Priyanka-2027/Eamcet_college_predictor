# 🚀 How to Run the AP EAMCET Predictor Project

This guide provides step-by-step instructions to set up and run the AP EAMCET College Predictor application locally.

## 📋 Prerequisites

*   **Node.js** (v14 or higher) installed.
*   **MongoDB** installed locally or a MongoDB Atlas account.

## 📂 Project Structure

*   `project/` - Frontend (React + Vite)
*   `project/backend/` - Backend (Node.js + Express + MongoDB)

---

## 🛠️ Step 1: Backend Setup

1.  **Navigate to the backend directory:**
    ```bash
    cd project/backend
    ```

2.  **Install Dependencies:**
    ```bash
    npm install
    ```

3.  **Configure Environment Variables:**
    *   Create a `.env` file in the `backend` directory.
    *   Copy the contents from `.env.example` or use the following:
    ```env
    PORT=5000
    MONGODB_URI=mongodb://localhost:27017/eamcet_predictor
    JWT_SECRET=your_super_secret_key_change_this
    NODE_ENV=development
    CORS_ORIGINS=http://localhost:5173
    ```
    *(Note: Replace `MONGODB_URI` with your actual connection string if using Atlas)*

4.  **Import Sample Data:**
    *   This populates the database with colleges and cutoff data.
    *   Ensure your MongoDB is running.
    ```bash
    node scripts/importSampleData.js
    ```
    *   *You should see a success message indicating colleges and cutoffs were imported.*

5.  **Start the Backend Server:**
    ```bash
    npm run dev
    ```
    *   *The server should start on `http://localhost:5000`.*

---

## 💻 Step 2: Frontend Setup

1.  **Open a new terminal** and navigate to the project root (frontend):
    ```bash
    cd project
    ```

2.  **Install Dependencies:**
    ```bash
    npm install
    ```

3.  **Configure Environment Variables:**
    *   Create a `.env` file in the `project` directory.
    *   Add the backend API URL:
    ```env
    VITE_API_URL=http://localhost:5000/api
    ```

4.  **Start the Frontend Development Server:**
    ```bash
    npm run dev
    ```
    *   *The application should be accessible at `http://localhost:5173`.*

---

## 🌐 Step 3: Accessing the Application

1.  Open your browser and go to **`http://localhost:5173`**.
2.  **Register** a new account or **Login** if you already have one.
3.  **Explore Features:**
    *   **Predictor:** Enter your rank and details to find colleges.
    *   **Search:** Look up specific colleges by name or district.
    *   **Compare:** Select colleges to compare them side-by-side.
    *   **Analysis:** View charts and insights about the data.

---

## 🐞 Troubleshooting

*   **Network Error?** Ensure the backend server is running on port 5000 and `VITE_API_URL` is correct in the frontend `.env`.
*   **Database Connection Error?** Check your `MONGODB_URI` and ensure MongoDB is running.
*   **No Data?** Make sure you ran the `importSampleData.js` script successfully.

---

## 📜 Scripts

*   **Backend:**
    *   `npm run dev`: Starts the server with nodemon (auto-restart).
    *   `npm start`: Starts the server normally.
    *   `node scripts/importSampleData.js`: Imports sample data.
    *   `node scripts/checkBranches.js`: Checks available branches in DB.

*   **Frontend:**
    *   `npm run dev`: Starts the development server.
    *   `npm run build`: Builds the project for production.
    *   `npm run preview`: Previews the production build.
