# 📤 How to Run This Project on a New Machine (Sharing Guide)

Use this guide if you have received this project folder and want to run it on your own computer from scratch.

## 📋 1. Prerequisites
Before you begin, ensure you have the following installed on your computer:
1.  **Node.js** (v14 or higher) - [Download Here](https://nodejs.org/)
2.  **MongoDB Community Server** - [Download Here](https://www.mongodb.com/try/download/community)
    *   *Make sure MongoDB is installed and running as a service.*

---

## 🗄️ 2. Database Setup (Crucial Step)
Since the database is local, you need to create your own copy of the data.

1.  **Open a terminal** and navigate to the `backend` folder inside the project:
    ```bash
    cd project/backend
    ```

2.  **Install Backend Dependencies:**
    ```bash
    npm install
    ```

3.  **Configure Environment:**
    *   Create a new file named `.env` in the `backend` folder.
    *   Paste the following content into it:
        ```env
        PORT=5000
        MONGODB_URI=mongodb://localhost:27017/eamcet_predictor
        JWT_SECRET=development_secret_key_123
        NODE_ENV=development
        CORS_ORIGINS=http://localhost:5173
        ```

4.  **Import the Data:**
    *   Run this command to populate your local database with colleges and cutoffs:
        ```bash
        node scripts/importSampleData.js
        ```
    *   ✅ *You should see a message saying "Data Imported Successfully".*

5.  **Start the Backend Server:**
    ```bash
    npm run dev
    ```
    *   *Keep this terminal window open.*

---

## 💻 3. Frontend Setup

1.  **Open a NEW terminal window** (do not close the backend one).
2.  Navigate to the main `project` folder:
    ```bash
    cd project
    ```

3.  **Install Frontend Dependencies:**
    ```bash
    npm install
    ```

4.  **Configure Environment:**
    *   Create a new file named `.env` in the `project` folder.
    *   Paste the following content:
        ```env
        VITE_API_URL=http://localhost:5000/api
        ```

5.  **Start the Application:**
    ```bash
    npm run dev
    ```

---

## 🚀 4. Access the App
*   Open your browser and go to: **`http://localhost:5173`**
*   Since this is a fresh database, you will need to **Register** a new account (Sign Up) to log in.

---

## ❓ Troubleshooting
*   **"Connection Refused"**: Make sure your MongoDB service is running in the background.
*   **"Network Error"**: Ensure the backend terminal is still running and shows "Connected to MongoDB".
