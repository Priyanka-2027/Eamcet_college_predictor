const express = require('express');
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');
const { body, query, validationResult } = require('express-validator');
const College = require('../models/College');
const CutoffData = require('../models/CutoffData');
const { authenticateToken, requireAdmin, optionalAuth } = require('../middleware/auth');

const router = express.Router();

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'text/csv' || file.originalname.endsWith('.csv')) {
      cb(null, true);
    } else {
      cb(new Error('Only CSV files are allowed'), false);
    }
  }
});

// @route   GET /api/colleges/predict
// @desc    Get college predictions based on filters using cutoff_data_2024
// @access  Public
router.get('/predict', [
  query('rank')
    .isInt({ min: 1 })
    .withMessage('Rank must be a positive integer'),
  query('gender')
    .isIn(['BOYS', 'GIRLS'])
    .withMessage('Gender must be BOYS or GIRLS'),
  query('category')
    .isIn(['OC', 'SC', 'ST', 'BCA', 'BCB', 'BCC', 'BCD', 'BCE', 'OC_EWS'])
    .withMessage('Invalid category')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const {
      rank,
      gender,
      category,
      branches,
      district,
      collegeType,
      maxFee,
      limit = 50
    } = req.query;

    // Parse branches (can be comma-separated string or array)
    // If empty or not provided, return all branches
    let branchArray = [];
    if (branches) {
      branchArray = Array.isArray(branches) ? branches : branches.split(',').filter(b => b.trim());
    }

    const filters = {
      rank: parseInt(rank),
      gender,
      category,
      branches: branchArray,
      district,
      collegeType,
      maxFee: maxFee ? parseInt(maxFee) : null
    };

    // Use the new CutoffData model with advanced filtering
    const predictions = await CutoffData.getPredictions(filters);
    const limitedResults = predictions.slice(0, parseInt(limit));

    res.json({
      success: true,
      count: limitedResults.length,
      totalFound: predictions.length,
      colleges: limitedResults,
      filters: filters
    });

  } catch (error) {
    console.error('Prediction error:', error);
    res.status(500).json({
      success: false,
      error: 'Prediction failed',
      message: error.message || 'Internal server error'
    });
  }
});

// @route   GET /api/colleges
// @desc    Get all colleges with pagination and filtering
// @access  Public
router.get('/', optionalAuth, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 20,
      search,
      branch,
      type,
      district,
      sortBy = 'COLLEGE_NAME',
      sortOrder = 'asc'
    } = req.query;

    const query = { isActive: true };

    // Add search filter
    if (search) {
      query.$or = [
        { COLLEGE_NAME: { $regex: search, $options: 'i' } },
        { INSTCODE: { $regex: search, $options: 'i' } },
        { PLACE: { $regex: search, $options: 'i' } }
      ];
    }

    // Add filters
    if (branch) query.branch_code = branch;
    if (type) query.TYPE = type;
    if (district) query.DIST = district;

    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [colleges, total] = await Promise.all([
      College.find(query)
        .sort(sortOptions)
        .skip(skip)
        .limit(parseInt(limit)),
      College.countDocuments(query)
    ]);

    res.json({
      success: true,
      colleges,
      pagination: {
        current: parseInt(page),
        pages: Math.ceil(total / parseInt(limit)),
        total,
        limit: parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Get colleges error:', error);
    res.status(500).json({
      error: 'Failed to fetch colleges',
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/colleges/stats
// @desc    Get college statistics
// @access  Public
router.get('/stats', async (req, res) => {
  try {
    const [
      totalColleges,
      govtColleges,
      privateColleges,
      aidedColleges,
      branchStats,
      districtStats
    ] = await Promise.all([
      College.countDocuments({ isActive: true }),
      College.countDocuments({ isActive: true, TYPE: 'GOVT' }),
      College.countDocuments({ isActive: true, TYPE: 'PVT' }),
      College.countDocuments({ isActive: true, TYPE: 'AIDED' }),
      // Aggregate colleges by branch
      College.aggregate([
        { $match: { isActive: true } },
        { $group: { _id: '$branch_code', count: { $sum: 1 } } },
        { $sort: { count: -1 } }
      ]),
      // Aggregate colleges by district
      College.aggregate([
        { $match: { isActive: true } },
        { $group: { _id: '$DIST', count: { $sum: 1 } } },
        { $sort: { count: -1 } }
      ])
    ]);

    res.json({
      success: true,
      stats: {
        totalColleges,
        govtColleges,
        privateColleges,
        aidedColleges,
        totalBranches: branchStats.length,
        totalDistricts: districtStats.length,
        branchDistribution: branchStats.map(b => ({ name: b._id, count: b.count })),
        districtDistribution: districtStats.map(d => ({ name: d._id, count: d.count }))
      }
    });

  } catch (error) {
    console.error('Stats error:', error);
    res.status(500).json({
      error: 'Failed to fetch statistics',
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/colleges/:id
// @desc    Get single college by ID
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const college = await College.findById(req.params.id);
    
    if (!college) {
      return res.status(404).json({
        error: 'College not found',
        message: 'The requested college does not exist'
      });
    }

    res.json({
      success: true,
      college
    });

  } catch (error) {
    console.error('Get college error:', error);
    res.status(500).json({
      error: 'Failed to fetch college',
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/colleges
// @desc    Add new college
// @access  Private (Admin only)
router.post('/', authenticateToken, requireAdmin, [
  body('INSTCODE').notEmpty().withMessage('Institution code is required'),
  body('COLLEGE_NAME').notEmpty().withMessage('College name is required'),
  body('TYPE').isIn(['GOVT', 'PVT', 'AIDED']).withMessage('Invalid college type'),
  body('branch_code').isIn(['CSE', 'ECE', 'EEE', 'MECH', 'CIVIL', 'IT', 'CHEM', 'AERO', 'AUTO', 'BIOTECH']).withMessage('Invalid branch code'),
  body('COLLEGE_FEE').isNumeric().withMessage('College fee must be a number')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const college = new College(req.body);
    await college.save();

    res.status(201).json({
      success: true,
      message: 'College added successfully',
      college
    });

  } catch (error) {
    console.error('Add college error:', error);
    
    if (error.code === 11000) {
      return res.status(400).json({
        error: 'Duplicate entry',
        message: 'A college with this code and branch already exists'
      });
    }

    res.status(500).json({
      error: 'Failed to add college',
      message: 'Internal server error'
    });
  }
});

// @route   PUT /api/colleges/:id
// @desc    Update college
// @access  Private (Admin only)
router.put('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const college = await College.findByIdAndUpdate(
      req.params.id,
      { ...req.body, lastUpdated: new Date() },
      { new: true, runValidators: true }
    );

    if (!college) {
      return res.status(404).json({
        error: 'College not found',
        message: 'The requested college does not exist'
      });
    }

    res.json({
      success: true,
      message: 'College updated successfully',
      college
    });

  } catch (error) {
    console.error('Update college error:', error);
    res.status(500).json({
      error: 'Failed to update college',
      message: 'Internal server error'
    });
  }
});

// @route   DELETE /api/colleges/:id
// @desc    Delete college
// @access  Private (Admin only)
router.delete('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const college = await College.findByIdAndDelete(req.params.id);

    if (!college) {
      return res.status(404).json({
        error: 'College not found',
        message: 'The requested college does not exist'
      });
    }

    res.json({
      success: true,
      message: 'College deleted successfully'
    });

  } catch (error) {
    console.error('Delete college error:', error);
    res.status(500).json({
      error: 'Failed to delete college',
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/colleges/upload-csv
// @desc    Upload colleges via CSV
// @access  Private (Admin only)
router.post('/upload-csv', authenticateToken, requireAdmin, upload.single('csvFile'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        error: 'Upload failed',
        message: 'No CSV file provided'
      });
    }

    const results = [];
    const errors = [];
    let processedCount = 0;

    // Read and parse CSV file
    fs.createReadStream(req.file.path)
      .pipe(csv())
      .on('data', (data) => {
        try {
          // Clean and validate data
          const collegeData = {
            SNO: parseInt(data.SNO) || 0,
            INSTCODE: data.INSTCODE?.trim().toUpperCase(),
            COLLEGE_NAME: data.COLLEGE_NAME?.trim().toUpperCase(),
            TYPE: data.TYPE?.trim().toUpperCase(),
            REGION: data.REGION?.trim().toUpperCase(),
            DIST: data.DIST?.trim().toUpperCase(),
            PLACE: data.PLACE?.trim().toUpperCase(),
            COED: data.COED?.trim().toUpperCase(),
            AFFL: data.AFFL?.trim().toUpperCase(),
            ESTD: parseInt(data.ESTD) || new Date().getFullYear(),
            branch_code: data.branch_code?.trim().toUpperCase(),
            COLLEGE_FEE: parseInt(data.COLLEGE_FEE) || 0
          };

          // Add cutoff data
          const cutoffFields = ['OC_BOYS', 'OC_GIRLS', 'SC_BOYS', 'SC_GIRLS', 'ST_BOYS', 'ST_GIRLS', 
                               'BCA_BOYS', 'BCA_GIRLS', 'BCB_BOYS', 'BCB_GIRLS', 'BCC_BOYS', 'BCC_GIRLS',
                               'BCD_BOYS', 'BCD_GIRLS', 'BCE_BOYS', 'BCE_GIRLS', 'OC_EWS_BOYS', 'OC_EWS_GIRLS'];

          cutoffFields.forEach(field => {
            const value = data[field];
            if (value && value !== '' && !isNaN(value)) {
              collegeData[field] = parseInt(value);
            }
          });

          results.push(collegeData);
        } catch (error) {
          errors.push(`Row ${processedCount + 1}: ${error.message}`);
        }
        processedCount++;
      })
      .on('end', async () => {
        try {
          // Insert colleges in batches
          const batchSize = 100;
          let insertedCount = 0;
          let duplicateCount = 0;

          for (let i = 0; i < results.length; i += batchSize) {
            const batch = results.slice(i, i + batchSize);
            
            for (const collegeData of batch) {
              try {
                await College.create(collegeData);
                insertedCount++;
              } catch (error) {
                if (error.code === 11000) {
                  duplicateCount++;
                } else {
                  errors.push(`Failed to insert ${collegeData.COLLEGE_NAME}: ${error.message}`);
                }
              }
            }
          }

          // Clean up uploaded file
          fs.unlinkSync(req.file.path);

          res.json({
            success: true,
            message: 'CSV upload completed',
            stats: {
              totalRows: processedCount,
              inserted: insertedCount,
              duplicates: duplicateCount,
              errors: errors.length
            },
            errors: errors.slice(0, 10) // Return first 10 errors
          });

        } catch (error) {
          console.error('CSV processing error:', error);
          fs.unlinkSync(req.file.path);
          
          res.status(500).json({
            error: 'CSV processing failed',
            message: 'Internal server error during data insertion'
          });
        }
      })
      .on('error', (error) => {
        console.error('CSV parsing error:', error);
        fs.unlinkSync(req.file.path);
        
        res.status(400).json({
          error: 'CSV parsing failed',
          message: 'Invalid CSV format or corrupted file'
        });
      });

  } catch (error) {
    console.error('CSV upload error:', error);
    
    // Clean up file if it exists
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }

    res.status(500).json({
      error: 'Upload failed',
      message: 'Internal server error'
    });
  }
});

module.exports = router;