const express = require('express');
const mongoose = require('mongoose');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const College = require('../models/College');
const { authenticateToken, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/users/favorites
// @desc    Get user's favorite colleges
// @access  Private
router.get('/favorites', authenticateToken, async (req, res) => {
  try {
    const CutoffData = require('../models/CutoffData');
    const user = await User.findById(req.user._id);
    
    if (!user.favorites || user.favorites.length === 0) {
      return res.json({
        success: true,
        favorites: []
      });
    }

    // Filter favorites into valid ObjectIds and others
    const validObjectIds = user.favorites.filter(id => mongoose.Types.ObjectId.isValid(id));
    const otherIds = user.favorites; // INSTCODEs are just strings

    // Fetch favorites from both collections
    const [cutoffFavorites, collegeFavorites] = await Promise.all([
      // Only query CutoffData with valid ObjectIds to avoid CastError
      validObjectIds.length > 0 
        ? CutoffData.find({ _id: { $in: validObjectIds } })
        : Promise.resolve([]),
      
      // Query College by INSTCODE (using all favorites as potential codes)
      College.find({ INSTCODE: { $in: otherIds } })
    ]);

    // Combine results
    const favorites = [...cutoffFavorites, ...collegeFavorites];

    res.json({
      success: true,
      favorites: favorites
    });

  } catch (error) {
    console.error('Get favorites error:', error);
    res.status(500).json({
      error: 'Failed to fetch favorites',
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/users/favorites/:collegeId
// @desc    Add college to favorites
// @access  Private
router.post('/favorites/:collegeId', authenticateToken, async (req, res) => {
  try {
    const { collegeId } = req.params;

    // Note: collegeId can be from either College or CutoffData collection
    // We'll just store the ID and let the frontend handle the display
    const user = await User.findById(req.user._id);
    
    // Check if already in favorites
    if (user.favorites.includes(collegeId)) {
      return res.status(400).json({
        error: 'Already in favorites',
        message: 'This college is already in your favorites'
      });
    }

    user.favorites.push(collegeId);
    await user.save();

    res.json({
      success: true,
      message: 'College added to favorites',
      favoritesCount: user.favorites.length
    });

  } catch (error) {
    console.error('Add favorite error:', error);
    res.status(500).json({
      error: 'Failed to add favorite',
      message: 'Internal server error'
    });
  }
});

// @route   DELETE /api/users/favorites/:collegeId
// @desc    Remove college from favorites
// @access  Private
router.delete('/favorites/:collegeId', authenticateToken, async (req, res) => {
  try {
    const { collegeId } = req.params;
    console.log('🗑️ Removing favorite:', collegeId, 'for user:', req.user._id);
    
    const user = await User.findById(req.user._id);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found',
        message: 'User not found'
      });
    }

    const beforeCount = user.favorites.length;
    user.favorites = user.favorites.filter(id => id.toString() !== collegeId);
    const afterCount = user.favorites.length;
    
    await user.save();
    
    console.log(`✅ Removed favorite. Before: ${beforeCount}, After: ${afterCount}`);

    res.json({
      success: true,
      message: 'College removed from favorites',
      favoritesCount: user.favorites.length
    });

  } catch (error) {
    console.error('❌ Remove favorite error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to remove favorite',
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/users
// @desc    Get all users (Admin only)
// @access  Private (Admin)
router.get('/', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 20,
      search,
      role,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = req.query;

    const query = {};

    // Add search filter
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }

    // Add role filter
    if (role) query.role = role;

    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [users, total] = await Promise.all([
      User.find(query)
        .select('-password')
        .sort(sortOptions)
        .skip(skip)
        .limit(parseInt(limit)),
      User.countDocuments(query)
    ]);

    res.json({
      success: true,
      users,
      pagination: {
        current: parseInt(page),
        pages: Math.ceil(total / parseInt(limit)),
        total,
        limit: parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({
      error: 'Failed to fetch users',
      message: 'Internal server error'
    });
  }
});

// @route   PUT /api/users/:id/status
// @desc    Update user status (Admin only)
// @access  Private (Admin)
router.put('/:id/status', authenticateToken, requireAdmin, [
  body('isActive')
    .isBoolean()
    .withMessage('isActive must be a boolean value')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const { id } = req.params;
    const { isActive } = req.body;

    // Prevent admin from deactivating themselves
    if (id === req.user._id.toString()) {
      return res.status(400).json({
        error: 'Invalid operation',
        message: 'You cannot deactivate your own account'
      });
    }

    const user = await User.findByIdAndUpdate(
      id,
      { isActive },
      { new: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'The requested user does not exist'
      });
    }

    res.json({
      success: true,
      message: `User ${isActive ? 'activated' : 'deactivated'} successfully`,
      user
    });

  } catch (error) {
    console.error('Update user status error:', error);
    res.status(500).json({
      error: 'Failed to update user status',
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/users/stats
// @desc    Get user statistics (Admin only)
// @access  Private (Admin)
router.get('/stats', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const [
      totalUsers,
      activeUsers,
      students,
      admins,
      recentUsers
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ isActive: true }),
      User.countDocuments({ role: 'student' }),
      User.countDocuments({ role: 'admin' }),
      User.countDocuments({
        createdAt: { $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) }
      })
    ]);

    res.json({
      success: true,
      stats: {
        totalUsers,
        activeUsers,
        inactiveUsers: totalUsers - activeUsers,
        students,
        admins,
        recentUsers
      }
    });

  } catch (error) {
    console.error('User stats error:', error);
    res.status(500).json({
      error: 'Failed to fetch user statistics',
      message: 'Internal server error'
    });
  }
});

// @route   PUT /api/users/profile
// @desc    Update user profile and preferences
// @access  Private
router.put('/profile', authenticateToken, [
  body('name').optional().trim().isLength({ min: 2, max: 50 }).withMessage('Name must be between 2 and 50 characters'),
  body('profile.rank').optional().isInt({ min: 1 }).withMessage('Rank must be at least 1'),
  body('profile.category').optional().isIn(['OC', 'SC', 'ST', 'BCA', 'BCB', 'BCC', 'BCD', 'BCE', 'OC_EWS']).withMessage('Invalid category'),
  body('profile.gender').optional().isIn(['BOYS', 'GIRLS']).withMessage('Invalid gender'),
  body('profile.district').optional().trim()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const { name, profile } = req.body;
    const user = await User.findById(req.user._id);

    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'The requested user does not exist'
      });
    }

    if (name) user.name = name;
    if (profile) {
      user.profile = {
        ...user.profile,
        ...profile
      };
      
      // Also update lastPrediction to stay in sync
      user.lastPrediction = {
        rank: profile.rank || user.profile.rank,
        category: profile.category || user.profile.category,
        gender: profile.gender || user.profile.gender,
        timestamp: new Date()
      };
    }

    await user.save();

    res.json({
      success: true,
      message: 'Profile updated successfully',
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        profile: user.profile,
        lastPrediction: user.lastPrediction
      }
    });

  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({
      error: 'Failed to update profile',
      message: 'Internal server error'
    });
  }
});

module.exports = router;