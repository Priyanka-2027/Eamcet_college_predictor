const mongoose = require('mongoose');

const collegeSchema = new mongoose.Schema({
  SNO: {
    type: Number,
    required: true
  },
  INSTCODE: {
    type: String,
    required: [true, 'Institution code is required'],
    trim: true,
    uppercase: true
  },
  COLLEGE_NAME: {
    type: String,
    required: [true, 'College name is required'],
    trim: true,
    uppercase: true
  },
  TYPE: {
    type: String,
    required: true,
    enum: ['GOVT', 'PVT', 'AIDED', 'UNIV', 'SF', 'SS', 'PU'],
    uppercase: true
  },
  REGION: {
    type: String,
    required: true,
    trim: true,
    uppercase: true
  },
  DIST: {
    type: String,
    required: true,
    trim: true,
    uppercase: true
  },
  PLACE: {
    type: String,
    required: true,
    trim: true,
    uppercase: true
  },
  COED: {
    type: String,
    required: true,
    enum: ['COED', 'BOYS', 'GIRLS'],
    uppercase: true
  },
  AFFL: {
    type: String,
    required: true,
    trim: true,
    uppercase: true
  },
  ESTD: {
    type: Number,
    required: true,
    min: [1800, 'Establishment year seems too early'],
    max: [new Date().getFullYear(), 'Establishment year cannot be in the future']
  },
  branch_code: {
    type: String,
    required: [true, 'Branch code is required'],
    trim: true,
    uppercase: true
    // enum removed to allow all branch codes from data
  },
  
  // Cutoff ranks for different categories and genders
  OC_BOYS: { type: Number, min: 0 },
  OC_GIRLS: { type: Number, min: 0 },
  SC_BOYS: { type: Number, min: 0 },
  SC_GIRLS: { type: Number, min: 0 },
  ST_BOYS: { type: Number, min: 0 },
  ST_GIRLS: { type: Number, min: 0 },
  BCA_BOYS: { type: Number, min: 0 },
  BCA_GIRLS: { type: Number, min: 0 },
  BCB_BOYS: { type: Number, min: 0 },
  BCB_GIRLS: { type: Number, min: 0 },
  BCC_BOYS: { type: Number, min: 0 },
  BCC_GIRLS: { type: Number, min: 0 },
  BCD_BOYS: { type: Number, min: 0 },
  BCD_GIRLS: { type: Number, min: 0 },
  BCE_BOYS: { type: Number, min: 0 },
  BCE_GIRLS: { type: Number, min: 0 },
  OC_EWS_BOYS: { type: Number, min: 0 },
  OC_EWS_GIRLS: { type: Number, min: 0 },
  
  COLLEGE_FEE: {
    type: Number,
    required: true,
    min: [0, 'College fee cannot be negative']
  },
  
  // Additional metadata
  year: {
    type: Number,
    default: new Date().getFullYear()
  },
  isActive: {
    type: Boolean,
    default: true
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Indexes for faster queries
collegeSchema.index({ INSTCODE: 1, branch_code: 1 });
collegeSchema.index({ TYPE: 1 });
collegeSchema.index({ DIST: 1 });
collegeSchema.index({ branch_code: 1 });
collegeSchema.index({ COLLEGE_NAME: 'text' });

// Compound indexes for prediction queries
collegeSchema.index({ branch_code: 1, TYPE: 1, DIST: 1 });
collegeSchema.index({ OC_BOYS: 1, OC_GIRLS: 1 });
collegeSchema.index({ SC_BOYS: 1, SC_GIRLS: 1 });

// Virtual for getting cutoff by category and gender
collegeSchema.methods.getCutoff = function(category, gender) {
  const field = `${category}_${gender}`;
  return this[field];
};

// Static method to get prediction results
collegeSchema.statics.getPredictions = async function(filters) {
  const { rank, gender, category, branches, district, collegeType, maxFee } = filters;
  
  let query = {
    isActive: true,
    branch_code: { $in: branches }
  };
  
  // Add district filter if specified
  if (district && district !== 'ALL') {
    query.DIST = district;
  }
  
  // Add college type filter if specified
  if (collegeType && collegeType !== 'ALL') {
    query.TYPE = collegeType;
  }
  
  // Add fee filter if specified
  if (maxFee) {
    query.COLLEGE_FEE = { $lte: maxFee };
  }
  
  // Get all matching colleges
  const colleges = await this.find(query);
  
  // Filter by cutoff rank
  const categoryField = `${category}_${gender}`;
  const eligibleColleges = colleges.filter(college => {
    const cutoff = college[categoryField];
    return cutoff && rank <= cutoff;
  });
  
  // Sort by cutoff rank (lower is better)
  eligibleColleges.sort((a, b) => {
    const cutoffA = a[categoryField] || Infinity;
    const cutoffB = b[categoryField] || Infinity;
    return cutoffA - cutoffB;
  });
  
  return eligibleColleges;
};

module.exports = mongoose.model('College', collegeSchema);