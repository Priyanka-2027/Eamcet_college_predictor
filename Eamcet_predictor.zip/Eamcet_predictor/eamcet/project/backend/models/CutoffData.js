const mongoose = require('mongoose');

const cutoffDataSchema = new mongoose.Schema({
  college_name: {
    type: String,
    required: [true, 'College name is required'],
    trim: true,
    uppercase: true,
    index: true
  },
  branch: {
    type: String,
    required: [true, 'Branch is required'],
    trim: true,
    uppercase: true,
    index: true
  },
  gender: {
    type: String,
    required: [true, 'Gender is required'],
    enum: ['BOYS', 'GIRLS', 'COED'],
    uppercase: true,
    index: true
  },
  category: {
    type: String,
    required: [true, 'Category is required'],
    enum: ['OC', 'SC', 'ST', 'BCA', 'BCB', 'BCC', 'BCD', 'BCE', 'OC_EWS'],
    uppercase: true,
    index: true
  },
  district: {
    type: String,
    required: [true, 'District is required'],
    trim: true,
    uppercase: true,
    index: true
  },
  closing_rank: {
    type: Number,
    required: [true, 'Closing rank is required'],
    min: [1, 'Closing rank must be positive'],
    index: true
  },
  // Additional metadata from original data
  college_code: {
    type: String,
    trim: true,
    uppercase: true
  },
  college_type: {
    type: String,
    enum: ['GOVT', 'PVT', 'AIDED', 'UNIV', 'SF', 'SS', 'PU'],
    uppercase: true
  },
  region: {
    type: String,
    trim: true,
    uppercase: true
  },
  place: {
    type: String,
    trim: true,
    uppercase: true
  },
  affiliation: {
    type: String,
    trim: true,
    uppercase: true
  },
  established_year: {
    type: Number,
    min: 1800
  },
  college_fee: {
    type: Number,
    min: 0,
    default: 0
  },
  year: {
    type: Number,
    default: 2024
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

// Compound indexes for faster prediction queries
cutoffDataSchema.index({ branch: 1, gender: 1, category: 1 });
cutoffDataSchema.index({ closing_rank: 1, branch: 1 });
cutoffDataSchema.index({ district: 1, branch: 1, gender: 1 });
cutoffDataSchema.index({ college_name: 1, branch: 1, category: 1, gender: 1 });

// Static method to get predictions with advanced filtering
cutoffDataSchema.statics.getPredictions = async function(filters) {
  const { rank, gender, category, branches, district, collegeType, maxFee } = filters;
  
  // Build the query with filtering rules
  let query = {
    isActive: true,
    closing_rank: { $gte: rank } // closing_rank >= user_rank
  };
  
  // Gender filtering: match user gender OR include Co-Ed for females
  if (gender === 'GIRLS') {
    query.gender = { $in: ['GIRLS', 'COED'] };
  } else {
    query.gender = { $in: ['BOYS', 'COED'] };
  }
  
  // Category filtering: match user category OR include OC if user rank fits
  const categoryOptions = [category];
  // Always include OC as it's generally available for all categories
  if (category !== 'OC') {
    categoryOptions.push('OC');
  }
  query.category = { $in: categoryOptions };
  
  // Branch filtering
  if (branches && branches.length > 0) {
    query.branch = { $in: branches };
  }
  // If branches array is empty, return all branches (no filter)
  
  // District filtering
  if (district && district !== '' && district !== 'ALL') {
    query.district = district;
  }
  
  // College type filtering
  if (collegeType && collegeType !== '' && collegeType !== 'ALL') {
    query.college_type = collegeType;
  }
  
  // Fee filtering
  if (maxFee && maxFee > 0) {
    query.college_fee = { $lte: maxFee };
  }
  
  // Execute query and sort by closing_rank ascending (best colleges first)
  const results = await this.find(query)
    .sort({ closing_rank: 1 }) // Lower closing rank = better college
    .lean();
  
  return results;
};

// Method to get unique values for filters
cutoffDataSchema.statics.getFilterOptions = async function() {
  const [branches, districts, collegeTypes] = await Promise.all([
    this.distinct('branch', { isActive: true }),
    this.distinct('district', { isActive: true }),
    this.distinct('college_type', { isActive: true })
  ]);
  
  return {
    branches: branches.sort(),
    districts: districts.sort(),
    collegeTypes: collegeTypes.sort()
  };
};

module.exports = mongoose.model('CutoffData', cutoffDataSchema, 'cutoff_data_2024');
