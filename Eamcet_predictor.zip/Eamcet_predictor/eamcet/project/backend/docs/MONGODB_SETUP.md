# MongoDB Atlas Setup Guide

This guide will walk you through setting up MongoDB Atlas for your AP EAMCET College Predictor application.

## 🚀 Step 1: Create MongoDB Atlas Account

1. **Visit MongoDB Atlas**: Go to [https://cloud.mongodb.com/](https://cloud.mongodb.com/)
2. **Sign Up**: Create a free account or sign in if you already have one
3. **Choose Free Tier**: Select the M0 Sandbox (Free Forever) option

## 🏗️ Step 2: Create a New Cluster

1. **Create New Project**: 
   - Click "New Project"
   - Name it "EAMCET-Predictor" or similar
   - Click "Create Project"

2. **Build a Database**:
   - Click "Build a Database"
   - Choose "M0 FREE" tier
   - Select your preferred cloud provider (AWS recommended)
   - Choose a region closest to your users (Asia Pacific for India)
   - Name your cluster (e.g., "eamcet-cluster")
   - Click "Create"

## 🔐 Step 3: Configure Database Access

1. **Create Database User**:
   - Go to "Database Access" in the left sidebar
   - Click "Add New Database User"
   - Choose "Password" authentication
   - Username: `eamcet_admin` (or your choice)
   - Password: Generate a secure password (save it!)
   - Database User Privileges: "Read and write to any database"
   - Click "Add User"

2. **Network Access**:
   - Go to "Network Access" in the left sidebar
   - Click "Add IP Address"
   - For development: Click "Allow Access from Anywhere" (0.0.0.0/0)
   - For production: Add your specific IP addresses
   - Click "Confirm"

## 🔗 Step 4: Get Connection String

1. **Connect to Cluster**:
   - Go to "Database" in the left sidebar
   - Click "Connect" on your cluster
   - Choose "Connect your application"
   - Select "Node.js" and version "4.1 or later"
   - Copy the connection string

2. **Connection String Format**:
   ```
   mongodb+srv://<username>:<password>@<cluster-name>.mongodb.net/<database-name>?retryWrites=true&w=majority
   ```

## ⚙️ Step 5: Configure Your Application

1. **Update .env file**:
   ```bash
   cd backend
   cp .env.example .env
   ```

2. **Edit .env file**:
   ```env
   MONGODB_URI=mongodb+srv://eamcet_admin:YOUR_PASSWORD@eamcet-cluster.xxxxx.mongodb.net/eamcet_predictor?retryWrites=true&w=majority
   JWT_SECRET=your_super_secret_jwt_key_here_make_it_long_and_random
   PORT=5000
   NODE_ENV=development
   CORS_ORIGINS=http://localhost:3000,http://localhost:5173
   ```

   **Replace**:
   - `YOUR_PASSWORD` with your database user password
   - `xxxxx` with your actual cluster identifier
   - `your_super_secret_jwt_key_here` with a strong random string

## 📊 Step 6: Import Sample Data

### Option A: Use Sample Data (Quick Start)
```bash
cd backend
npm run seed
```

### Option B: Import from CSV
```bash
cd backend
node scripts/importCSV.js data/sample-colleges.csv
```

### Option C: Import Your Own CSV
1. Prepare your CSV file with the required columns (see sample-colleges.csv)
2. Run the import script:
   ```bash
   node scripts/importCSV.js path/to/your/colleges.csv
   ```

## 🧪 Step 7: Test the Connection

1. **Start your backend**:
   ```bash
   cd backend
   npm run dev
   ```

2. **Check the logs**:
   - You should see "✅ Connected to MongoDB Atlas"
   - Visit `http://localhost:5000/api/health` to verify

3. **Test API endpoints**:
   ```bash
   # Get college statistics
   curl http://localhost:5000/api/colleges/stats
   
   # Register a test user
   curl -X POST http://localhost:5000/api/auth/register \
     -H "Content-Type: application/json" \
     -d '{"name":"Test User","email":"test@example.com","password":"password123"}'
   ```

## 📈 Step 8: Monitor Your Database

1. **Atlas Dashboard**:
   - Monitor connections, operations, and performance
   - View real-time metrics and alerts

2. **Collections**:
   - `colleges`: Stores all college and cutoff data
   - `users`: Stores user accounts and preferences

## 🔧 CSV File Format

Your CSV file should have these columns:

```csv
SNO,INSTCODE,COLLEGE_NAME,TYPE,REGION,DIST,PLACE,COED,AFFL,ESTD,branch_code,OC_BOYS,OC_GIRLS,SC_BOYS,SC_GIRLS,ST_BOYS,ST_GIRLS,BCA_BOYS,BCA_GIRLS,BCB_BOYS,BCB_GIRLS,BCC_BOYS,BCC_GIRLS,BCD_BOYS,BCD_GIRLS,BCE_BOYS,BCE_GIRLS,OC_EWS_BOYS,OC_EWS_GIRLS,COLLEGE_FEE
```

**Required Fields**:
- `INSTCODE`: Institution code
- `COLLEGE_NAME`: Full college name
- `TYPE`: GOVT/PVT/AIDED
- `branch_code`: CSE/ECE/EEE/MECH/CIVIL/IT
- `COLLEGE_FEE`: Annual fee amount

**Cutoff Fields** (Optional but recommended):
- Format: `{CATEGORY}_{GENDER}` (e.g., OC_BOYS, SC_GIRLS)
- Categories: OC, SC, ST, BCA, BCB, BCC, BCD, BCE, OC_EWS
- Genders: BOYS, GIRLS

## 🚨 Troubleshooting

### Connection Issues
- **Error: "MongoNetworkError"**: Check your IP whitelist in Network Access
- **Error: "Authentication failed"**: Verify username/password in connection string
- **Error: "Connection timeout"**: Check your internet connection and cluster status

### Data Import Issues
- **CSV parsing errors**: Ensure proper CSV format with headers
- **Duplicate key errors**: Normal for existing data, script continues
- **Validation errors**: Check required fields are present

### Performance Tips
- **Indexing**: The app automatically creates indexes for fast queries
- **Connection Pooling**: MongoDB driver handles this automatically
- **Query Optimization**: Use filters to limit result sets

## 📞 Support

If you encounter issues:
1. Check MongoDB Atlas status page
2. Review connection string format
3. Verify network access settings
4. Check application logs for detailed error messages

## 🎉 Success!

Once everything is set up, you should have:
- ✅ MongoDB Atlas cluster running
- ✅ Database user with proper permissions
- ✅ College data imported
- ✅ Backend API connected and working
- ✅ Sample users for testing

Your AP EAMCET College Predictor is now ready with a production-grade database!