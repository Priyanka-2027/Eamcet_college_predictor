const mongoose = require('mongoose');
require('dotenv').config();

async function showDbInfo() {
  try {
    // Connect to the local database
    console.log('🔌 Connecting to:', process.env.MONGODB_URI);
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected successfully!');

    const db = mongoose.connection.db;
    
    // Get Database Name
    console.log('\n📦 Database Name:', db.databaseName);

    // Get All Collections
    const collections = await db.listCollections().toArray();
    console.log('\n📚 Collections found:');
    
    for (const col of collections) {
      const count = await db.collection(col.name).countDocuments();
      console.log(`   - ${col.name}: ${count} documents`);
    }

    // Get Storage Info
    const stats = await db.stats();
    console.log('\n💾 Storage Size:', (stats.storageSize / 1024 / 1024).toFixed(2), 'MB');
    console.log('📂 Data Size:', (stats.dataSize / 1024 / 1024).toFixed(2), 'MB');

    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

showDbInfo();
