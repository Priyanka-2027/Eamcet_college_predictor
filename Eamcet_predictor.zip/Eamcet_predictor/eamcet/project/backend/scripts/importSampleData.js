const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
const College = require('../models/College');
const CutoffData = require('../models/CutoffData');
require('dotenv').config();

// Path to the sample data file
const DATA_FILE_PATH = 'd:/Downloads/eamcet/sampleData';

// Helper function to transform college data to cutoff data
function transformToCutoffData(college) {
  const cutoffDocs = [];
  const categories = ['OC', 'SC', 'ST', 'BCA', 'BCB', 'BCC', 'BCD', 'BCE', 'OC_EWS'];
  const genders = ['BOYS', 'GIRLS'];

  // Handle the weird key with newline
  const branchCode = college['branch\n_code'] || college['branch_code'];

  categories.forEach(category => {
    genders.forEach(gender => {
      const field = `${category}_${gender}`;
      let cutoff = college[field];

      // Handle empty strings or invalid numbers
      if (cutoff === '' || cutoff === null || cutoff === undefined) {
        return;
      }
      
      cutoff = Number(cutoff);
      if (isNaN(cutoff)) return;

      cutoffDocs.push({
        college_name: college.COLLEG_NAME || college.COLLEGE_NAME, // Handle potential key difference
        branch: branchCode,
        gender: gender,
        category: category,
        district: college.DIST,
        closing_rank: cutoff,
        college_code: college.INSTCODE,
        college_type: college.TYPE,
        region: college.REGION,
        place: college.PLACE,
        affiliation: college.AFFL,
        established_year: college.ESTD,
        college_fee: Number(college.COLLEGE_FEE) || 0,
        year: 2024 // Assuming 2024 as per previous context
      });
    });
  });

  return cutoffDocs;
}

async function importData() {
  try {
    console.log('🔗 Connecting to MongoDB...');
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB');

    // Read the file
    console.log(`📖 Reading data from ${DATA_FILE_PATH}...`);
    const rawData = fs.readFileSync(DATA_FILE_PATH, 'utf8');
    const colleges = JSON.parse(rawData);
    console.log(`📊 Found ${colleges.length} records in file`);

    // Clear existing data
    console.log('🧹 Clearing existing data...');
    await College.deleteMany({});
    await CutoffData.deleteMany({});
    console.log('✅ Existing data cleared');

    // Transform and insert into College collection
    // We need to map the keys to match the Mongoose schema if they differ
    console.log('🔄 Preparing College documents...');
    const collegeDocs = colleges.map(c => ({
      SNO: c.SNO,
      INSTCODE: c.INSTCODE,
      COLLEGE_NAME: c.COLLEG_NAME || c.COLLEGE_NAME, // Map COLLEG_NAME to COLLEGE_NAME
      TYPE: c.TYPE,
      REGION: c.REGION,
      DIST: c.DIST,
      PLACE: c.PLACE,
      COED: c.COED,
      AFFL: c.AFFL,
      ESTD: c.ESTD,
      branch_code: c['branch\n_code'] || c.branch_code,
      COLLEGE_FEE: Number(c.COLLEGE_FEE) || 0,
      // Map cutoff fields
      OC_BOYS: Number(c.OC_BOYS) || 0,
      OC_GIRLS: Number(c.OC_GIRLS) || 0,
      SC_BOYS: Number(c.SC_BOYS) || 0,
      SC_GIRLS: Number(c.SC_GIRLS) || 0,
      ST_BOYS: Number(c.ST_BOYS) || 0,
      ST_GIRLS: Number(c.ST_GIRLS) || 0,
      BCA_BOYS: Number(c.BCA_BOYS) || 0,
      BCA_GIRLS: Number(c.BCA_GIRLS) || 0,
      BCB_BOYS: Number(c.BCB_BOYS) || 0,
      BCB_GIRLS: Number(c.BCB_GIRLS) || 0,
      BCC_BOYS: Number(c.BCC_BOYS) || 0,
      BCC_GIRLS: Number(c.BCC_GIRLS) || 0,
      BCD_BOYS: Number(c.BCD_BOYS) || 0,
      BCD_GIRLS: Number(c.BCD_GIRLS) || 0,
      BCE_BOYS: Number(c.BCE_BOYS) || 0,
      BCE_GIRLS: Number(c.BCE_GIRLS) || 0,
      OC_EWS_BOYS: Number(c.OC_EWS_BOYS) || 0,
      OC_EWS_GIRLS: Number(c.OC_EWS_GIRLS) || 0,
      year: 2024
    }));

    // Insert into College collection in batches
    console.log('📚 Inserting into College collection...');
    const batchSize = 500;
    for (let i = 0; i < collegeDocs.length; i += batchSize) {
      const batch = collegeDocs.slice(i, i + batchSize);
      await College.insertMany(batch);
      process.stdout.write(`\rProcessed ${Math.min(i + batchSize, collegeDocs.length)}/${collegeDocs.length} colleges`);
    }
    console.log('\n✅ College collection populated');

    // Transform and insert into CutoffData collection
    console.log('🔄 Preparing CutoffData documents...');
    const allCutoffDocs = [];
    for (const college of colleges) {
      const cutoffDocs = transformToCutoffData(college);
      allCutoffDocs.push(...cutoffDocs);
    }

    console.log(`📚 Inserting ${allCutoffDocs.length} records into CutoffData collection...`);
    for (let i = 0; i < allCutoffDocs.length; i += batchSize) {
      const batch = allCutoffDocs.slice(i, i + batchSize);
      await CutoffData.insertMany(batch);
      process.stdout.write(`\rProcessed ${Math.min(i + batchSize, allCutoffDocs.length)}/${allCutoffDocs.length} cutoffs`);
    }
    console.log('\n✅ CutoffData collection populated');

    console.log('\n🎉 Data import completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('\n❌ Error importing data:', error);
    process.exit(1);
  }
}

importData();
