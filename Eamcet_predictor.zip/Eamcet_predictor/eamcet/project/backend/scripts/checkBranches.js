const mongoose = require('mongoose');
const College = require('../models/College');
require('dotenv').config();

async function checkBranches() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB');

    const branchStats = await College.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$branch_code', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    console.log('Top 20 Branches:');
    branchStats.slice(0, 20).forEach(b => {
      console.log(`'${b._id}': ${b.count}`);
    });

    process.exit(0);
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
}

checkBranches();
