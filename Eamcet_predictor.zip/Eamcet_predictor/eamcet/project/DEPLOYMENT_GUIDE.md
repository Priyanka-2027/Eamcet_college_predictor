# 🚀 Deployment Guide for AP EAMCET Predictor

This guide will help you deploy your full-stack application (Frontend + Backend + Database) to the internet for free.

## 📦 Phase 1: Database Deployment (MongoDB Atlas)
Since your local database cannot be accessed from the internet, you must move it to the cloud.

1.  **Create Account:** Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) and sign up.
2.  **Create Cluster:** Create a new **FREE (M0)** cluster.
3.  **Network Access:** Go to "Network Access" -> "Add IP Address" -> Select **"Allow Access from Anywhere"** (0.0.0.0/0).
4.  **Database User:** Go to "Database Access" -> Create a new user (remember the username and password).
5.  **Get Connection String:**
    *   Click "Connect" -> "Drivers".
    *   Copy the string (e.g., `mongodb+srv://<username>:<password>@cluster0.mongodb.net/...`).
    *   Replace `<password>` with your actual password.
6.  **Upload Your Data:**
    *   Update your local `backend/.env` file with this new `MONGODB_URI`.
    *   Run the import script locally: `node scripts/importSampleData.js`.
    *   *This pushes your local data to the cloud!*

---

## 🛠️ Phase 2: Backend Deployment (Render.com)
Render is a great free platform for hosting Node.js APIs.

1.  **Push Code to GitHub:**
    *   Create a repository on GitHub.
    *   Push your entire `project` folder to it.
2.  **Create Web Service on Render:**
    *   Sign up at [Render.com](https://render.com/).
    *   Click **"New +"** -> **"Web Service"**.
    *   Connect your GitHub repository.
3.  **Configure Settings:**
    *   **Root Directory:** `backend` (Important!)
    *   **Build Command:** `npm install`
    *   **Start Command:** `node server.js`
4.  **Environment Variables:**
    *   Add the following variables in the "Environment" tab:
        *   `MONGODB_URI`: (Paste your Atlas connection string from Phase 1)
        *   `JWT_SECRET`: (Create a strong random password)
        *   `NODE_ENV`: `production`
        *   `CORS_ORIGINS`: `*` (Allow all for now, or put your frontend URL later)
5.  **Deploy:** Click "Create Web Service". Wait for it to go live. Copy the **Backend URL** (e.g., `https://my-api.onrender.com`).

---

## 🌐 Phase 3: Frontend Deployment (Vercel)
Vercel is the best place to host React/Vite apps.

1.  **Sign up at Vercel:** Go to [Vercel.com](https://vercel.com/) and login with GitHub.
2.  **Import Project:**
    *   Click **"Add New..."** -> **"Project"**.
    *   Select your GitHub repository.
3.  **Configure Project:**
    *   **Framework Preset:** Vite
    *   **Root Directory:** Click "Edit" and select the `project` folder (the frontend one).
4.  **Environment Variables:**
    *   Add a variable named `VITE_API_URL`.
    *   Value: Paste your **Render Backend URL** from Phase 2 (e.g., `https://my-api.onrender.com/api`).
    *   *Note: Make sure to add `/api` at the end if your routes expect it.*
5.  **Deploy:** Click "Deploy".

---

## 🎉 Done!
Your application is now live!
*   **Frontend URL:** (Provided by Vercel) - Share this with users.
*   **Backend URL:** (Provided by Render) - API running in background.
*   **Database:** (MongoDB Atlas) - Storing data safely in the cloud.
